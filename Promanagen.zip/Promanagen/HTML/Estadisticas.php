<?php
// EstadisticasMaestro.php
session_start();

// Conexión a la BD (ajusta credenciales si hace falta)
$conn = new mysqli("localhost", "root", "", "promanage");
if ($conn->connect_error) die("Conexión fallida: " . $conn->connect_error);

// --- Cerrar sesión del maestro (solo maestro) ---
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    unset($_SESSION['maestro_logged'], $_SESSION['maestro']);
    header("Location: " . basename(__FILE__));
    exit;
}

// --- Manejo de formulario de login por correo (maestro) ---
$maestro_logged = !empty($_SESSION['maestro_logged']);
$maestro = $_SESSION['maestro'] ?? null;
$login_error = '';

if (!$maestro_logged && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['correo_maestro'])) {
    $correo = trim($_POST['correo_maestro']);
    if ($correo === '') {
        $login_error = "Ingresa un correo válido.";
    } else {
        $stmt = $conn->prepare("SELECT id, nombre, correo FROM maestros WHERE correo = ? LIMIT 1");
        if (!$stmt) die("Error en prepare maestros: " . $conn->error);
        $stmt->bind_param("s", $correo);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res && $res->num_rows > 0) {
            $maestro = $res->fetch_assoc();
            $_SESSION['maestro_logged'] = true;
            $_SESSION['maestro'] = $maestro;
            $maestro_logged = true;
        } else {
            $login_error = "Correo de maestro no encontrado.";
        }
        $stmt->close();
    }
}

// --- Función para obtener archivos de un proyecto ---
function getArchivos($conn, $proyecto_id) {
    $archivos = [];
    $stmt = $conn->prepare("SELECT id, nombre_archivo, ruta, fecha_subida FROM archivos WHERE proyecto_id = ? ORDER BY fecha_subida DESC");
    if (!$stmt) die("Error en prepare archivos: " . $conn->error);
    $stmt->bind_param("i", $proyecto_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) $archivos[] = $row;
    $stmt->close();
    return $archivos;
}

// --- Manejo de calificación por maestro (solo si está logueado) ---
// Nota: se añade comprobación de que el proyecto pertenezca al maestro (proyectos.maestro_id)
$msg_calificacion = '';
if ($maestro_logged && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['calificar'])) {
    $proy_id = (int)($_POST['proyecto_id'] ?? 0);
    $comentario = trim($_POST['comentario'] ?? '');
    $calificacion = ($_POST['calificacion'] !== '') ? (int)$_POST['calificacion'] : null;

    if ($proy_id <= 0) {
        $msg_calificacion = "Proyecto inválido.";
    } else {
        // verificar que el proyecto tiene maestro_id = maestro[id]
        $stmtChk = $conn->prepare("SELECT maestro_id FROM proyectos WHERE id = ? LIMIT 1");
        if (!$stmtChk) die("Error en prepare comprobación proyecto: " . $conn->error);
        $stmtChk->bind_param("i", $proy_id);
        $stmtChk->execute();
        $resChk = $stmtChk->get_result();
        $rowChk = $resChk->fetch_assoc();
        $stmtChk->close();

        $maestro_id = (int)($maestro['id'] ?? 0);
        $proy_maestro_id = isset($rowChk['maestro_id']) ? (int)$rowChk['maestro_id'] : 0;

        if ($proy_maestro_id !== $maestro_id) {
            $msg_calificacion = "No tienes permisos para calificar este proyecto.";
        } else {
            // Actualizar la tabla proyectos
            if ($calificacion === null) {
                $stmt = $conn->prepare("UPDATE proyectos SET comentario = ? WHERE id = ?");
                if (!$stmt) die("Error en prepare actualizar comentario: " . $conn->error);
                $stmt->bind_param("si", $comentario, $proy_id);
            } else {
                $stmt = $conn->prepare("UPDATE proyectos SET calificacion = ?, comentario = ? WHERE id = ?");
                if (!$stmt) die("Error en prepare actualizar calificación: " . $conn->error);
                $stmt->bind_param("isi", $calificacion, $comentario, $proy_id);
            }
            if ($stmt->execute()) {
                $msg_calificacion = "Calificación registrada correctamente.";
            } else {
                $msg_calificacion = "Error al guardar: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}

// --- Obtener proyectos que tienen maestro_id = maestro.id (si maestro logueado) ---
// Si no hay maestro logueado, no mostramos proyectos.
$proyectos = [];
if ($maestro_logged) {
    $maestro_id = (int)$maestro['id'];
    $stmt = $conn->prepare("
        SELECT p.*, u.correo AS alumno_correo 
        FROM proyectos p
        LEFT JOIN usuarios u ON p.usuario_id = u.id
        WHERE p.maestro_id = ?
        ORDER BY p.fecha_creacion DESC
    ");
    if (!$stmt) die("Error en prepare proyectos: " . $conn->error);
    $stmt->bind_param("i", $maestro_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) $proyectos[] = $row;
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Estadísticas - Maestro</title>
<link rel="stylesheet" href="/Promanagen/CSS/repositorio.css">
<style>
:root{
    --bg:#0d1117; --surface:#161b22; --text:#c9d1d9; --accent:#238636; --muted:#8b949e;
}
body{background:var(--bg);color:var(--text);margin:0;font-family:system-ui, sans-serif;}
.header{display:flex;justify-content:space-between;padding:12px 20px;background:var(--surface);align-items:center;}
.user-area{display:flex;align-items:center;gap:.8rem;}
.user-avatar{width:44px;height:44px;border-radius:8px;background:rgba(255,255,255,0.06);display:flex;align-items:center;justify-content:center;font-weight:700;color:var(--text);}
.container{max-width:1100px;margin:20px auto;padding:1rem;}
.repositorio{background:var(--surface);padding:20px;border-radius:10px;margin-bottom:15px;}
.btn{background:var(--accent);color:#fff;padding:.5rem .8rem;border:none;border-radius:8px;cursor:pointer;text-decoration:none;}
input,textarea,select{width:100%;padding:8px;margin:6px 0;border-radius:6px;border:1px solid rgba(255,255,255,0.12);background:#0d1117;color:var(--text);}
label{font-size:0.9rem;color:var(--muted);}
.small-error{color:#ff8b8b;}
.proyecto-card{border:1px solid rgba(255,255,255,0.06);padding:12px;border-radius:8px;margin-bottom:12px;background:linear-gradient(180deg, rgba(255,255,255,0.01), transparent);}
.meta-line{color:var(--muted);font-size:0.9rem;margin-bottom:8px;}
.row{display:flex;gap:12px;align-items:flex-start;}
.col{flex:1;}
@media (max-width:800px){ .row{flex-direction:column;}}
.header-right{margin-left:auto;}
.note { color: var(--muted); font-size: .95rem; margin-top: .6rem; }
</style>
</head>
<body>

<header class="header">
    <div class="logo" style="font-weight:700;">📁 ProjectFolio — Estadísticas (Maestro)
    </div>

    <div class="header-right">
        <?php if ($maestro_logged && !empty($maestro['correo'])): ?>
            <div class="user-area">
                <div style="text-align:right;">
                    <div style="font-size:.95rem;"><?php echo htmlspecialchars($maestro['nombre'] ?? $maestro['correo']); ?></div>
                    <div style="font-size:.75rem;color:var(--muted);">Maestro</div>
                </div>
                <div class="user-avatar"><?php echo strtoupper(substr($maestro['correo'],0,2)); ?></div>
                <a href="<?php echo basename(__FILE__); ?>?action=logout" class="btn" style="margin-left:12px;">Cerrar sesión</a>
            </div>
        <?php else: ?>
            <a href="<?php echo basename(__FILE__); ?>" class="btn">Acceso Maestro</a>
            <a href="../DieñoEli/login.html" class="btn" style="margin-left:12px;">Soy estudiante</a>
        <?php endif; ?>
    </div>
</header>

<div class="container">

<?php if (!$maestro_logged): ?>
    <!-- Formulario simple para que el maestro inicie con su correo -->
    <div class="repositorio">
        <h2>Ingreso Maestro</h2>
        <p style="color:var(--muted);">Introduce tu correo de maestro para acceder al panel de evaluación.</p>
        <?php if ($login_error) echo "<div class='small-error'>{$login_error}</div>"; ?>
        <form method="post" style="margin-top:8px;">
            <label>Correo del Maestro</label>
            <input type="email" name="correo_maestro" required placeholder="maestro@dominio.edu">
            <button type="submit" class="btn">Iniciar sesión</button>
        </form>
        <p class="note">(Si más tarde agregas contraseñas, aquí podrás ampliar la autenticación.)</p>
    </div>
<?php else: ?>
    <!-- Panel maestro: lista de proyectos asignados al maestro -->
    <div class="repositorio">
        <h2>Panel de Evaluación — Bienvenido <?php echo htmlspecialchars($maestro['nombre'] ?? $maestro['correo']); ?></h2>
        <?php if ($msg_calificacion) echo "<div style='margin:.5rem 0;color:#a7f3d0;'>{$msg_calificacion}</div>"; ?>

        <?php if (empty($proyectos)): ?>
            <p>No hay proyectos asignados a ti.</p>
        <?php else: ?>
            <?php foreach ($proyectos as $p):
                $archivos = getArchivos($conn, $p['id']);
            ?>
                <div class="proyecto-card">
                    <div class="row">
                        <div class="col">
                            <h3 style="margin:0 0 .4rem;"><?php echo htmlspecialchars($p['nombre']); ?></h3>
                            <div class="meta-line">
                                Alumno: <?php echo htmlspecialchars($p['alumno_correo'] ?? '—'); ?> • Creado: <?php echo htmlspecialchars($p['fecha_creacion']); ?> • Último commit: <?php echo htmlspecialchars($p['ultimo_commit'] ?: 'Sin actividad'); ?>
                            </div>
                            <p style="margin:.25rem 0;color:var(--text);"><?php echo htmlspecialchars($p['descripcion']); ?></p>

                            <h4 style="margin:.5rem 0 .2rem;">Archivos</h4>
                            <?php if (empty($archivos)): ?>
                                <p style="color:var(--muted);margin:0;">No hay archivos subidos.</p>
                            <?php else: ?>
                                <ul style="margin:.2rem 0 0 1.1rem;padding:0;color:var(--text);">
                                    <?php foreach ($archivos as $a): ?>
                                        <li style="margin:.25rem 0;">
                                            <a href="<?php echo htmlspecialchars($a['ruta']); ?>" target="_blank"><?php echo htmlspecialchars($a['nombre_archivo']); ?></a>
                                            <small style="color:var(--muted)"> — <?php echo htmlspecialchars($a['fecha_subida']); ?></small>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </div>

                        <div style="width:320px;min-width:220px;">
                            <form method="post">
                                <input type="hidden" name="proyecto_id" value="<?php echo (int)$p['id']; ?>">
                                <label>Calificación (0-100)</label>
                                <input type="number" name="calificacion" min="0" max="100" value="<?php echo isset($p['calificacion']) ? htmlspecialchars($p['calificacion']) : ''; ?>">

                                <label>Comentarios</label>
                                <textarea name="comentario" rows="4"><?php echo isset($p['comentario']) ? htmlspecialchars($p['comentario']) : ''; ?></textarea>

                                <button type="submit" name="calificar" class="btn" style="width:100%;margin-top:.6rem;">Guardar evaluación</button>
                            </form>

                            <?php if (isset($p['calificacion']) && $p['calificacion'] !== null && $p['calificacion'] !== ''): ?>
                                <div style="margin-top:.6rem;padding:.6rem;border-radius:8px;background:rgba(255,255,255,0.02);">
                                    <strong>Calificación actual:</strong> <?php echo htmlspecialchars($p['calificacion']); ?><br>
                                    <small style="color:var(--muted)"><?php echo htmlspecialchars($p['comentario'] ?? ''); ?></small>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
<?php endif; ?>

</div>

</body>
</html>
<?php
$conn->close();