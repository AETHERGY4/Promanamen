<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: Inicio.html");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
// asegúrate de tener el correo en la sesión
$usuario_correo = $_SESSION['usuario_correo'] ?? 'Usuario';

// Obtener id del proyecto y validar
$proyecto_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($proyecto_id <= 0) {
    header("Location: index.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "promanage");
if ($conn->connect_error) die("Conexión fallida: " . $conn->connect_error);

// ---------- Manejo POST: actualizar proyecto / agregar actividad / editar actividad / eliminar actividad ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_project') {
        $nombre = trim($_POST['nombre'] ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');
        $stmt = $conn->prepare("UPDATE proyectos SET nombre=?, descripcion=? WHERE id=? AND usuario_id=?");
        $stmt->bind_param("ssii", $nombre, $descripcion, $proyecto_id, $usuario_id);
        $stmt->execute();
        $stmt->close();
        header("Location: editar_proyecto.php?id=" . $proyecto_id);
        exit;
    }

    if ($action === 'add_activity') {
        $nombreA = trim($_POST['nombre'] ?? '');
        $miembro = trim($_POST['miembro'] ?? '');
        $fecha_inicio = $_POST['fecha_inicio'] ?: null;
        $fecha_fin = $_POST['fecha_fin'] ?: null;
        $estado = $_POST['estado'] ?? 'pendiente';

        if ($nombreA !== '') {
            $stmt = $conn->prepare("INSERT INTO actividades (proyecto_id, nombre, miembro, fecha_inicio, fecha_fin, estado) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("isssss", $proyecto_id, $nombreA, $miembro, $fecha_inicio, $fecha_fin, $estado);
            $stmt->execute();
            $stmt->close();
        }
        header("Location: editar_proyecto.php?id=" . $proyecto_id);
        exit;
    }

    if ($action === 'edit_activity') {
        $act_id = (int)($_POST['act_id'] ?? 0);
        $nombreA = trim($_POST['nombre'] ?? '');
        $miembro = trim($_POST['miembro'] ?? '');
        $fecha_inicio = $_POST['fecha_inicio'] ?: null;
        $fecha_fin = $_POST['fecha_fin'] ?: null;
        $estado = $_POST['estado'] ?? 'pendiente';

        if ($act_id && $nombreA !== '') {
            // Tipos: nombre (s), miembro (s), fecha_inicio (s), fecha_fin (s), estado (s), id (i), proyecto_id (i)
            $stmt = $conn->prepare("UPDATE actividades SET nombre=?, miembro=?, fecha_inicio=?, fecha_fin=?, estado=? WHERE id=? AND proyecto_id=?");
            if ($stmt) {
                $stmt->bind_param("sssssii", $nombreA, $miembro, $fecha_inicio, $fecha_fin, $estado, $act_id, $proyecto_id);
                $stmt->execute();
                $stmt->close();
            } else {
                // opcional: para depuración
                error_log("Prepare failed: " . $conn->error);
            }
        }
        header("Location: editar_proyecto.php?id=" . $proyecto_id);
        exit;
    }

    if ($action === 'delete_activity') {
        $act_id = (int)($_POST['act_id'] ?? 0);
        if ($act_id) {
            $stmt = $conn->prepare("DELETE FROM actividades WHERE id=? AND proyecto_id=?");
            $stmt->bind_param("ii", $act_id, $proyecto_id);
            $stmt->execute();
            $stmt->close();
        }
        header("Location: editar_proyecto.php?id=" . $proyecto_id);
        exit;
    }
}

// ---------- Obtener datos del proyecto ----------
$stmt = $conn->prepare("SELECT id, nombre, descripcion, usuario_id FROM proyectos WHERE id=? LIMIT 1");
$stmt->bind_param("i", $proyecto_id);
$stmt->execute();
$res = $stmt->get_result();
$proyecto = $res->fetch_assoc();
$stmt->close();

if (!$proyecto) {
    // proyecto no existe
    $conn->close();
    header("Location: index.php");
    exit;
}

// opcional: verificar que el usuario tiene permiso (es dueño) — si no, podrías impedir edición.
// si quieres permitir que el maestro o admin edite, ajusta la lógica. Aquí sólo permitimos al propietario:
if ((int)$proyecto['usuario_id'] !== (int)$usuario_id) {
    // No es el propietario: opción: redirigir o permitir sólo ver
    // Por seguridad simple lo redirigimos:
    $conn->close();
    header("Location: index.php");
    exit;
}

// ---------- Obtener actividades del proyecto ----------
$actividades = [];
$stmt = $conn->prepare("SELECT id, nombre, miembro, fecha_inicio, fecha_fin, estado FROM actividades WHERE proyecto_id = ? ORDER BY fecha_inicio IS NULL ASC, fecha_inicio ASC, id ASC");
$stmt->bind_param("i", $proyecto_id);
$stmt->execute();
$res = $stmt->get_result();
while ($r = $res->fetch_assoc()) $actividades[] = $r;
$stmt->close();

$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Editar Proyecto</title>
<link rel="stylesheet" href="/Promanagen/CSS/repositorio.css">
<style>
/* Header styles (mismo estilo del header que pediste) */
:root{
  --header-bg: #161b22;
  --text: #c9d1d9;
  --muted: #8b949e;
  --btn: #238636;
}
body { margin:0; font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial; background:#0d1117; color:var(--text); }

.header {
  display:flex;
  justify-content:space-between;
  align-items:center;
  padding:12px 20px;
  background: var(--header-bg);
  color: var(--text);
  box-shadow: 0 2px 6px rgba(0,0,0,0.35);
  gap:12px;
  flex-wrap:wrap;
}
.user-menu { display:flex; gap:.8rem; align-items:center; }
.user-avatar {
  width:44px; height:44px; border-radius:8px;
  background: rgba(255,255,255,0.06);
  display:flex; align-items:center; justify-content:center;
  color: var(--text); font-weight:700;
  font-size:0.95rem;
  flex-shrink:0;
}
.user-info { text-align:right; line-height:1; }
.user-info .name { font-size:0.95rem; font-weight:700; color: var(--text); }
.user-info .sub { font-size:0.78rem; color: var(--muted); }

.nav-links { display:flex; gap:.6rem; align-items:center; margin-left:12px; }
.nav-link {
  color: var(--muted);
  text-decoration:none; padding:.35rem .6rem; border-radius:6px;
  font-size:0.92rem;
}
.nav-link.active { color: var(--text); background: rgba(255,255,255,0.02); }

.header-right { display:flex; align-items:center; gap:.5rem; margin-left:auto; }
.btn {
  background: var(--btn);
  color: #fff;
  padding: .45rem .7rem;
  border-radius:8px;
  text-decoration:none;
  font-weight:600;
  border: none;
  cursor: pointer;
}
.btn:hover { filter:brightness(.95); }

.container{ max-width:1100px; margin:20px auto; padding:1rem; }
.repositorio { background:#161b22; padding:20px; border-radius:10px; color:var(--text); }

.activity-list { list-style:none; padding:0; margin:12px 0 0 0; display:grid; gap:10px; }
.activity-item { display:flex; gap:12px; align-items:flex-start; background: rgba(255,255,255,0.02); padding:12px; border-radius:8px; border:1px solid rgba(255,255,255,0.03); }
.activity-info { flex:1; }
.activity-title { font-weight:700; color:var(--text); }
.activity-meta { color:var(--muted); font-size:0.9rem; margin-top:6px; }
.activity-actions { display:flex; gap:8px; align-items:center; }
.small-btn { padding:6px 10px; border-radius:8px; font-size:0.9rem; text-decoration:none; color:var(--text); border:1px solid rgba(255,255,255,0.04); background:transparent; cursor:pointer; }
.small-btn:hover { background: rgba(255,255,255,0.02); transform:translateY(-2px); }

.add-activity-form { display:flex; gap:8px; margin-top:12px; flex-wrap:wrap; align-items:center; }
.input-inline { padding:8px 10px; border-radius:8px; border:1px solid rgba(255,255,255,0.04); background:#0d1117; color:var(--text); }
.input-inline[type="date"] { padding:6px 8px; }

.edit-panel { margin-top:8px; padding:10px; background: rgba(255,255,255,0.01); border-radius:8px; border:1px solid rgba(255,255,255,0.02); display:none; }
.edit-panel.show { display:block; }

@media (max-width:800px){
  .add-activity-form { flex-direction:column; align-items:stretch; }
  .activity-item { flex-direction:column; }
}
</style>
</head>
<body>
<header class="header">
    <div style="display:flex; gap:12px; align-items:center;">
        <div class="user-menu">
            <div style="display:flex;align-items:center;gap:.6rem;">
                <div class="user-info" style="text-align:left;">
                    <div class="name"><?php echo htmlspecialchars($usuario_correo); ?></div>
                    <div class="sub">Editar proyecto</div>
                </div>
                <div class="user-avatar"><?php echo strtoupper(substr($usuario_correo,0,2)); ?></div>
            </div>
        </div>

        <nav class="nav-links" aria-label="Navegación principal">
            <a href="index.php" class="nav-link">Mi Espacio</a>
            <a href="Explorar.php" class="nav-link">Explorar</a>
            <a href="Equipos.php" class="nav-link">Equipos</a>
            <a href="#" class="nav-link">Estadísticas</a>
        </nav>
    </div>

    <div class="header-right">
        <a href="index.php" class="btn">Volver</a>
    </div>
</header>

<main class="container">
    <div class="repositorio">
        <h2>Editar Proyecto</h2>

        <!-- Form actualizar proyecto -->
        <form method="post" style="margin-top:8px;">
            <input type="hidden" name="action" value="update_project">
            <label for="nombre">Nombre:</label><br>
            <input id="nombre" class="input-inline" type="text" name="nombre" value="<?php echo htmlspecialchars($proyecto['nombre']); ?>" style="width:100%;"><br><br>

            <label for="descripcion">Descripción:</label><br>
            <textarea id="descripcion" class="input-inline" name="descripcion" rows="4" style="width:100%;"><?php echo htmlspecialchars($proyecto['descripcion']); ?></textarea><br><br>

            <button type="submit" class="btn">Guardar Cambios</button>
        </form>

        <hr style="margin:18px 0; border-color: rgba(255,255,255,0.03)">

        <h3 style="margin:6px 0 10px 0;">Plan de trabajo (actividades)</h3>

        <?php if (count($actividades) === 0): ?>
            <div style="color:var(--muted); margin-bottom:8px;">Este proyecto no tiene actividades aún. Usa el formulario para agregar una.</div>
        <?php else: ?>
            <ul class="activity-list">
                <?php foreach($actividades as $act): ?>
                    <li class="activity-item" id="act-<?php echo $act['id']; ?>">
                        <div class="activity-info">
                            <div class="activity-title"><?php echo htmlspecialchars($act['nombre']); ?></div>
                            <div class="activity-meta">
                                <?php if (!empty($act['miembro'])): ?>Asignado a: <?php echo htmlspecialchars($act['miembro']); ?> • <?php endif; ?>
                                <?php if (!empty($act['fecha_inicio'])): ?>Inicio: <?php echo htmlspecialchars($act['fecha_inicio']); ?><?php endif; ?>
                                <?php if (!empty($act['fecha_fin'])): ?> • Fin: <?php echo htmlspecialchars($act['fecha_fin']); ?><?php endif; ?>
                                <?php if (!empty($act['estado'])): ?> • Estado: <?php echo htmlspecialchars($act['estado']); ?><?php endif; ?>
                            </div>

                            <div class="edit-panel" id="edit-panel-<?php echo $act['id']; ?>">
                                <form method="post">
                                    <input type="hidden" name="action" value="edit_activity">
                                    <input type="hidden" name="act_id" value="<?php echo $act['id']; ?>">
                                    <div style="display:flex; gap:8px; flex-wrap:wrap;">
                                        <input class="input-inline" name="nombre" value="<?php echo htmlspecialchars($act['nombre']); ?>" placeholder="Actividad">
                                        <input class="input-inline" name="miembro" value="<?php echo htmlspecialchars($act['miembro']); ?>" placeholder="Asignado a" style="max-width:200px;">
                                        <input class="input-inline" type="date" name="fecha_inicio" value="<?php echo htmlspecialchars($act['fecha_inicio']); ?>">
                                        <input class="input-inline" type="date" name="fecha_fin" value="<?php echo htmlspecialchars($act['fecha_fin']); ?>">
                                        <select name="estado" class="input-inline" style="max-width:160px;">
                                            <option value="pendiente" <?php if($act['estado']==='pendiente') echo 'selected'; ?>>Pendiente</option>
                                            <option value="en progreso" <?php if($act['estado']==='en progreso') echo 'selected'; ?>>En progreso</option>
                                            <option value="completada" <?php if($act['estado']==='completada') echo 'selected'; ?>>Completada</option>
                                        </select>
                                    </div>
                                    <div style="margin-top:8px; display:flex; gap:8px;">
                                        <button class="small-btn" type="submit">Guardar</button>
                                        <button type="button" class="small-btn" onclick="toggleEdit(<?php echo $act['id']; ?>)">Cancelar</button>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="activity-actions">
                            <button class="small-btn" onclick="toggleEdit(<?php echo $act['id']; ?>)">Editar</button>

                            <form method="post" style="display:inline;">
                                <input type="hidden" name="action" value="delete_activity">
                                <input type="hidden" name="act_id" value="<?php echo $act['id']; ?>">
                                <button class="small-btn" type="submit" onclick="return confirm('Eliminar actividad?')">Eliminar</button>
                            </form>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

        <form method="post" class="add-activity-form" style="margin-top:12px;">
            <input type="hidden" name="action" value="add_activity">
            <input name="nombre" class="input-inline" placeholder="Nueva actividad (ej. Preparar presentación)" required>
            <input name="miembro" class="input-inline" placeholder="Asignado a (nombre)">
            <input name="fecha_inicio" class="input-inline" type="date" placeholder="Fecha inicio">
            <input name="fecha_fin" class="input-inline" type="date" placeholder="Fecha fin">
            <select name="estado" class="input-inline" style="max-width:160px;">
                <option value="pendiente">Pendiente</option>
                <option value="en progreso">En progreso</option>
                <option value="completada">Completada</option>
            </select>
            <button class="btn" type="submit">Agregar actividad</button>
        </form>

    </div>
</main>

<script>
function toggleEdit(id) {
    const el = document.getElementById('edit-panel-' + id);
    if (!el) return;
    el.classList.toggle('show');
    if (el.classList.contains('show')) el.scrollIntoView({behavior:'smooth', block:'center'});
}
</script>
</body>
</html>