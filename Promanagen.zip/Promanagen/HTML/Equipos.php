<?php
session_start();
if (!isset($_SESSION['usuario_id'])) header("Location: ../HTML/Inicio.html");

$usuario_id = $_SESSION['usuario_id'];
$usuario_correo = $_SESSION['usuario_correo'] ?? 'Usuario';

// Conexión a BD
$conn = new mysqli("localhost","root","","promanage");
if ($conn->connect_error) die("Conexión fallida: ".$conn->connect_error);

// Crear nuevo equipo
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nombre'])) {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'] ?? '';

    $stmt = $conn->prepare("INSERT INTO proyectos (usuario_id, nombre, descripcion, fecha_creacion) VALUES (?, ?, ?, NOW())");
    if(!$stmt) die("Error en prepare: " . $conn->error);

    $stmt->bind_param("iss", $usuario_id, $nombre, $descripcion);
    $stmt->execute();
    $stmt->close();

    header("Location: Equipos.php");
    exit;
}

// Obtener equipos del usuario
$stmt = $conn->prepare("SELECT id, nombre, descripcion, fecha_creacion, ultimo_commit FROM proyectos WHERE usuario_id=? ORDER BY fecha_creacion DESC");
if(!$stmt) die("Error en prepare: " . $conn->error);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$teams = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Equipos - ProjectFolio</title>
<link rel="stylesheet" href="/Promanagen/CSS/Equipos.css">
<style>
body{margin:0;font-family:system-ui;background:#0d1117;color:#c9d1d9;}
.container{max-width:1100px;margin:0 auto;padding:1rem;}
.main-header{background:#161b22;padding:.8rem 0;border-bottom:1px solid rgba(255,255,255,0.03);}
.navbar{display:flex;justify-content:space-between;align-items:center;gap:1rem;}
.logo{color:#c9d1d9;text-decoration:none;font-weight:700;}
.nav-links{display:flex;gap:.6rem;align-items:center;}
.nav-link{color:#8b949e;text-decoration:none;padding:.4rem .6rem;border-radius:6px;}
.nav-link.active{color:#c9d1d9;background:rgba(255,255,255,0.02);}
.user-menu{display:flex;gap:.6rem;align-items:center;}
.btn{background:#238636;color:#fff;padding:.45rem .7rem;border-radius:8px;text-decoration:none;}
.btn-outline{border:1px solid rgba(255,255,255,0.06);padding:.35rem .6rem;color:#c9d1d9;background:transparent;border-radius:6px;text-decoration:none;}
.user-avatar{width:36px;height:36px;background:rgba(255,255,255,0.06);display:flex;align-items:center;justify-content:center;border-radius:6px;color:#c9d1d9;font-weight:700;}
.teams-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:1rem;}
.team-card{background:#161b22;padding:1rem;border-radius:10px;}
.team-avatar{width:44px;height:44px;background:rgba(255,255,255,0.06);display:flex;align-items:center;justify-content:center;border-radius:6px;color:#c9d1d9;font-weight:700;margin-bottom:.5rem;}
</style>
</head>
<body>
    <header class="main-header">
        <div class="container">
            <nav class="navbar">
                <a href="#" class="logo" onclick="showPage('dashboard')">
                    <span>📁</span>
                    ProjectFolio
                </a>
                <a href="../HTML/index.php" class="btn">Volver</a>
                <div class="nav-links">
                    <a href="../HTML/index.php" class="nav-link active" onclick="showPage('dashboard')">Mi Espacio</a>
                    <a href="../HTML/Explorar.php" class="nav-link" onclick="showPage('explore')">Explorar</a>
                    <a href="../HTML/Equipos.php" class="nav-link" onclick="showPage('teams')">Equipos</a>
                    <a href="../HTML/Calificaciones.php" class="nav-link" onclick="showPage('statistics')">Estadísticas</a>
                </div>
                
                <div class="user-menu">
                    <div style="display:flex;align-items:center;gap:.6rem;">
                        <div style="text-align:right;">
                            <div style="font-size:.85rem;"><?php echo htmlspecialchars($usuario_correo); ?></div>
                            <div style="font-size:.75rem;color:var(--muted);">Bienvenido</div>
                        </div>
                        <div class="user-avatar"><?php echo strtoupper(substr($usuario_correo,0,2)); ?></div>
                    </div>
                </div>
            </nav>
        </div>
    </header>

<main class="container">
    <div class="section-header">
        <h2 class="section-title">Mis Equipos</h2>
    </div>
    <!-- Listado de equipos -->
    <div class="teams-grid">
        <?php foreach($teams as $t): ?>
        <div class="team-card">
            <div class="team-avatar"><?php echo strtoupper(substr($t['nombre'],0,2)); ?></div>
            <h3><?php echo htmlspecialchars($t['nombre']); ?></h3>
            <p><?php echo htmlspecialchars($t['descripcion']); ?></p>
            <small>Creado: <?php echo $t['fecha_creacion']; ?></small>
        </div>
        <?php endforeach; ?>
    </div>
</main>
</body>
</html>