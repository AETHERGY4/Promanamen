<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: Inicio.html");
    exit;
}

// asegúrate de tener el correo en la sesión
$usuario_correo = $_SESSION['usuario_correo'] ?? 'Usuario';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);
    $descripcion = trim($_POST['descripcion']);
    $usuario_id = (int)$_SESSION['usuario_id']; // creador
    $maestro_id = isset($_POST['maestro_id']) ? (int)$_POST['maestro_id'] : null;
    // integrantes (array de ids) - podría no venir
    $integrantes = isset($_POST['integrantes']) && is_array($_POST['integrantes']) ? $_POST['integrantes'] : [];

    $conn = new mysqli("localhost", "root", "", "promanage");
    if ($conn->connect_errno) {
        die("Error de conexión: " . $conn->connect_error);
    }

    // Usar transacción para atomicidad
    $conn->autocommit(false);
    try {
        // 1) Insertar proyecto
        $stmt = $conn->prepare("INSERT INTO proyectos (usuario_id, maestro_id, nombre, descripcion) VALUES (?, ?, ?, ?)");
        if (!$stmt) throw new Exception("Prepare proyectos: " . $conn->error);
        $stmt->bind_param("iiss", $usuario_id, $maestro_id, $nombre, $descripcion);
        if (!$stmt->execute()) throw new Exception("Execute proyectos: " . $stmt->error);
        $project_id = $conn->insert_id;
        $stmt->close();

        // 2) Insertar integrantes (incluye el creador siempre)
        $stmtIns = $conn->prepare("INSERT INTO integrantes (proyecto_id, usuario_id) VALUES (?, ?)");
        if (!$stmtIns) throw new Exception("Prepare integrantes: " . $conn->error);

        // Insertar creador como integrante
        $stmtIns->bind_param("ii", $project_id, $usuario_id);
        if (!$stmtIns->execute()) throw new Exception("Execute integrante creador: " . $stmtIns->error);

        // Insertar otros integrantes seleccionados (evitar duplicados)
        $inserted = [$usuario_id => true]; // para no reinsertar al creador
        foreach ($integrantes as $i_uid) {
            $i_uid = (int)$i_uid;
            if ($i_uid <= 0) continue;
            if (isset($inserted[$i_uid])) continue;
            $stmtIns->bind_param("ii", $project_id, $i_uid);
            if (!$stmtIns->execute()) throw new Exception("Execute integrante ($i_uid): " . $stmtIns->error);
            $inserted[$i_uid] = true;
        }
        $stmtIns->close();

        // Commit
        $conn->commit();
        $conn->autocommit(true);
        $conn->close();

        header("Location: index.php");
        exit;
    } catch (Exception $e) {
        $conn->rollback();
        $conn->autocommit(true);
        $conn->close();
        // Manejo simple de error — en producción muestra un mensaje amigable / loguear el error
        die("Error al crear proyecto: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Crear Proyecto</title>
<link rel="stylesheet" href="/Promanagen/CSS/repositorio.css">
<style>
/* Header styles (mismo estilo del header que pediste) */
:root{
  --header-bg: #161b22;
  --text: #c9d1d9;
  --muted: #8b949e;
  --btn: #238636;
}
body { margin:0; font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial; background:#0d1117; color:var(--text); }

.header {
  display:flex;
  justify-content:space-between;
  align-items:center;
  padding:12px 20px;
  background: var(--header-bg);
  color: var(--text);
  box-shadow: 0 2px 6px rgba(0,0,0,0.35);
  gap:12px;
  flex-wrap:wrap;
}
.user-menu { display:flex; gap:.8rem; align-items:center; }
.user-avatar {
  width:44px; height:44px; border-radius:8px;
  background: rgba(255,255,255,0.06);
  display:flex; align-items:center; justify-content:center;
  color: var(--text); font-weight:700;
  font-size:0.95rem;
  flex-shrink:0;
}
.user-info { text-align:right; line-height:1; }
.user-info .name { font-size:0.95rem; font-weight:700; color: var(--text); }
.user-info .sub { font-size:0.78rem; color: var(--muted); }

.nav-links { display:flex; gap:.6rem; align-items:center; margin-left:12px; }
.nav-link {
  color: var(--muted);
  text-decoration:none; padding:.35rem .6rem; border-radius:6px;
  font-size:0.92rem;
}
.nav-link.active { color: var(--text); background: rgba(255,255,255,0.02); }

.header-right { display:flex; align-items:center; gap:.5rem; margin-left:auto; }
.btn {
  background: var(--btn);
  color: #fff;
  padding: .45rem .7rem;
  border-radius:8px;
  text-decoration:none;
  font-weight:600;
  border: none;
  cursor: pointer;
}
.btn:hover { filter:brightness(.95); }

/* Page layout */
.container{ max-width:1100px; margin:20px auto; padding:1rem; }
.repositorio { background:#161b22; padding:20px; border-radius:10px; color:var(--text); }
.input-field{ width:100%; padding:8px; border-radius:6px; background:#0d1117; border:1px solid rgba(255,255,255,0.03); color:var(--text); }
label{ color:var(--muted); font-size:0.95rem; }
small{ color:var(--muted); display:block; margin-bottom:6px; }
select[multiple] { height:150px; }
@media (max-width:800px){ .nav-links{ display:none; } }
</style>
</head>
<body>

<header class="header">
    <div style="display:flex; gap:12px; align-items:center;">
        <div class="user-menu">
            <div style="display:flex;align-items:center;gap:.6rem;">
                <div class="user-info" style="text-align:left;">
                    <div class="name"><?php echo htmlspecialchars($usuario_correo); ?></div>
                    <div class="sub">Bienvenido</div>
                </div>
                <div class="user-avatar"><?php echo strtoupper(substr($usuario_correo,0,2)); ?></div>
            </div>
        </div>

        <nav class="nav-links" aria-label="Navegación principal">
            <a href="../HTML/index.php" class="nav-link active" onclick="showPage('dashboard')">Mi Espacio</a>
            <a href="../HTML/Explorar.php" class="nav-link" onclick="showPage('explore')">Explorar</a>
            <a href="../HTML/Equipos.php" class="nav-link" onclick="showPage('teams')">Equipos</a>
            <a href="../HTML/Calificaciones.php" class="nav-link" onclick="showPage('statistics')">Estadísticas</a>
        </nav>
    </div>

    <div class="header-right">
        <a href="/Promanagen/HTML/index.php" class="btn">Volver</a>
    </div>
</header>

<main class="container">
    <div class="repositorio">
        <h2>Nuevo Proyecto</h2>
        <form method="post">
            <label>Nombre:</label><br>
            <input type="text" name="nombre" required class="input-field"><br><br>

            <label>Descripción:</label><br>
            <textarea name="descripcion" class="input-field" style="min-height:100px;"></textarea><br><br>

            <label>Maestro que administra:</label><br>
            <select name="maestro_id" required class="input-field">
                <option value="">Selecciona un maestro</option>
                <?php
                // Cargar maestros
                $conn = new mysqli("localhost", "root", "", "promanage");
                if ($conn->connect_errno === 0) {
                    $res = $conn->query("SELECT id, nombre FROM maestros");
                    while($row = $res->fetch_assoc()){
                        echo "<option value='".(int)$row['id']."'>".htmlspecialchars($row['nombre'])."</option>";
                    }
                    $res->free();
                }
                $conn->close();
                ?>
            </select><br><br>

            <label>Agregar integrantes:</label><br>
            <small>Selecciona usuarios que formarán parte del proyecto (el creador se agregará automáticamente)</small><br>
            <select name="integrantes[]" multiple size="6" class="input-field">
                <?php
                // Cargar posibles integrantes (usuarios)
                $conn2 = new mysqli("localhost", "root", "", "promanage");
                if ($conn2->connect_errno === 0) {
                    $res2 = $conn2->query("SELECT id, nombre, correo FROM usuarios");
                    while($u = $res2->fetch_assoc()){
                        if ((int)$u['id'] === (int)$_SESSION['usuario_id']) {
                            echo "<option value='".(int)$u['id']."' selected>".htmlspecialchars($u['nombre'])." (tú)</option>";
                        } else {
                            echo "<option value='".(int)$u['id']."'>".htmlspecialchars($u['nombre'])." - ".htmlspecialchars($u['correo'])."</option>";
                        }
                    }
                    $res2->free();
                }
                $conn2->close();
                ?>
            </select><br><br>

            <button type="submit" class="btn">Crear Proyecto</button>
        </form>
    </div>
</main>

</body>
</html>