<?php
session_start();
if (!isset($_SESSION['usuario_id'])) header("Location: Inicio.html");

$usuario_id = $_SESSION['usuario_id'];
$usuario_correo = $_SESSION['usuario_correo'] ?? 'Usuario';

// --- Obtener tema y personalizaciones del usuario ---
$applied_theme = 'dark';
$applied_color = '#238636';
$bg_url = null;
$btn_color = '#238636';
$header_color = '#161b22';
$text_color = '#c9d1d9';

$conn_theme = new mysqli("localhost", "root", "", "promanage");
if (!$conn_theme->connect_error) {
    $stmt_t = $conn_theme->prepare("SELECT theme, custom_color, bg_url, btn_color, header_color, text_color FROM usuarios WHERE id=? LIMIT 1");
    if ($stmt_t) {
        $stmt_t->bind_param("i",$usuario_id);
        $stmt_t->execute();
        $res_t = $stmt_t->get_result()->fetch_assoc();
        if ($res_t) {
            $applied_theme = in_array($res_t['theme'], ['dark','light','custom']) ? $res_t['theme'] : 'dark';
            $applied_color = preg_match('/^#[0-9A-Fa-f]{6}$/', $res_t['custom_color'] ?? '') ? $res_t['custom_color'] : $applied_color;
            $bg_url = !empty($res_t['bg_url']) ? $res_t['bg_url'] : null;
            $btn_color = preg_match('/^#[0-9A-Fa-f]{6}$/', $res_t['btn_color'] ?? '') ? $res_t['btn_color'] : $btn_color;
            $header_color = preg_match('/^#[0-9A-Fa-f]{6}$/', $res_t['header_color'] ?? '') ? $res_t['header_color'] : $header_color;
            $text_color = preg_match('/^#[0-9A-Fa-f]{6}$/', $res_t['text_color'] ?? '') ? $res_t['text_color'] : $text_color;
        }
        $stmt_t->close();
    }
}
$conn_theme->close();

// --- Obtener proyectos del usuario ---
$conn = new mysqli("localhost", "root", "", "promanage");
if ($conn->connect_error) die("Conexión fallida: " . $conn->connect_error);

$stmt = $conn->prepare("SELECT id, nombre, descripcion, fecha_creacion, ultimo_commit, maestro_id FROM proyectos WHERE usuario_id = ?");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

$proyectos = [];
while ($row = $result->fetch_assoc()) $proyectos[] = $row;
$stmt->close();

// --- Calcular avance por proyecto ---
$avance_proyectos = [];
foreach($proyectos as $proyecto){
    $stmt = $conn->prepare("
        SELECT COUNT(*) as total, 
               SUM(CASE WHEN fecha_fin IS NOT NULL AND fecha_fin<>'' THEN 1 ELSE 0 END) as completadas 
        FROM actividades WHERE proyecto_id = ?");
    $stmt->bind_param("i", $proyecto['id']);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $total = (int)($res['total'] ?? 0);
    $completadas = (int)($res['completadas'] ?? 0);
    $pendientes = $total - $completadas;
    $avance_proyectos[] = [
        'id' => $proyecto['id'],
        'nombre' => $proyecto['nombre'],
        'completadas' => $completadas,
        'pendientes' => $pendientes,
        'descripcion' => $proyecto['descripcion'],
        'fecha_creacion' => $proyecto['fecha_creacion'],
        'ultimo_commit' => $proyecto['ultimo_commit'],
        'maestro_id' => $proyecto['maestro_id'] ?? null
    ];
    $stmt->close();
}

// --- Avances generales ---
$hoy = date('Y-m-d');
$fecha_inicio_semana = date('Y-m-d', strtotime('monday this week'));
$fecha_inicio_semestre = date('Y-m-d', strtotime('-6 months'));

$avance_dia = 0;
$avance_semana = 0;
$avance_semestre = 0;

$stmt = $conn->prepare("
    SELECT a.fecha_inicio, a.fecha_fin
    FROM actividades a
    JOIN proyectos p ON a.proyecto_id = p.id
    WHERE p.usuario_id = ?");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

while($row = $result->fetch_assoc()){
    $fecha_ini = $row['fecha_inicio'];
    $fecha_fin = $row['fecha_fin'] ?: $fecha_ini;

    if($fecha_ini <= $hoy && $fecha_fin >= $hoy) $avance_dia++;
    if($fecha_ini >= $fecha_inicio_semana && $fecha_ini <= $hoy) $avance_semana++;
    if($fecha_ini >= $fecha_inicio_semestre && $fecha_ini <= $hoy) $avance_semestre++;
}
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ProjectFolio - Dashboard</title>

    <link rel="stylesheet" href="/Promanagen/CSS/repositorio.css">
    <style>
        :root{
          --bg: #0d1117; --surface: #161b22; --text: #c9d1d9; --accent: <?php echo htmlspecialchars($applied_color); ?>; --header: <?php echo htmlspecialchars($header_color); ?>; --muted: #8b949e;
        }
        body.theme-light { --bg: #ffffff; --surface: #f6f8fa; --text: #0b0b0b; --accent: #0b5cff; --header: #e6eefc; --muted: #6b7280; }
        body.theme-custom { --bg: #ffffff; --surface: #f6f8fa; --text: #0b0b0b; --muted: #6b7280; }

        body {
          background-color: var(--bg);
          color: var(--text);
          margin:0; padding:0; font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
          background-size: cover; background-position: center; background-attachment: fixed; position: relative;
        }
        .container{ max-width:1100px; margin:0 auto; padding:1rem; }
        .main-header{ background:var(--header); padding:0.8rem 0; border-bottom:1px solid rgba(255,255,255,0.03); }
        .navbar{ display:flex; align-items:center; justify-content:space-between; gap:1rem; }
        .logo{ color:var(--text); text-decoration:none; font-weight:700; font-size:1.1rem; display:flex; gap:.5rem; align-items:center; }
        .nav-links{ display:flex; gap:.6rem; align-items:center; }
        .nav-link{ color:var(--muted); text-decoration:none; padding:.4rem .6rem; border-radius:6px; font-size:.95rem; }
        .nav-link.active{ color:var(--text); background:rgba(255,255,255,0.02); }
        .user-menu{ display:flex; gap:.6rem; align-items:center; }
        .btn{ background:var(--accent); color:#fff; padding:.45rem .7rem; border-radius:8px; text-decoration:none; }
        .btn-outline{ border:1px solid rgba(255,255,255,0.06); padding:.35rem .6rem; color:var(--text); background:transparent; border-radius:6px; text-decoration:none; }
        .user-avatar{ width:36px; height:36px; background:rgba(255,255,255,0.06); display:flex; align-items:center; justify-content:center; border-radius:6px; color:var(--text); font-weight:700; }
        .main-content{ padding:1rem 0; }
        .section-header{ display:flex; justify-content:space-between; align-items:center; gap:1rem; margin:1rem 0; }
        .section-title{ margin:0; color:var(--text); }
        .dashboard-grid{ display:grid; grid-template-columns:repeat(4,1fr); gap:1rem; margin-bottom:1rem; }
        .dashboard-card{ background:var(--surface); padding:1rem; border-radius:10px; text-align:center; }
        .card-header{ display:flex; gap:.6rem; align-items:center; justify-content:center; }
        .card-icon{ font-size:1.6rem; }
        .stat-number{ font-size:1.6rem; font-weight:700; margin-top:.6rem; }
        .projects-grid{ display:grid; grid-template-columns:repeat(auto-fit,minmax(320px,1fr)); gap:1rem; }
        .project-card{ background:var(--surface); padding:1rem; border-radius:10px; }
        .project-status{ font-size:.8rem; padding:.2rem .5rem; border-radius:6px; display:inline-block; margin-bottom:.6rem; }
        .status-completed{ background:rgba(34,197,94,0.12); color:#a7f3d0; }
        .status-in-progress{ background:rgba(59,130,246,0.08); color:#bfdbfe; }
        .repo-actions a{ margin-right:.5rem; color:var(--text); text-decoration:none; background:var(--accent); padding:.3rem .5rem; border-radius:6px; font-size:.85rem; }
        .repositorio { background:var(--surface); padding:15px; margin:15px 0; border-radius:10px; }
        /* mobile adjustments */
        @media (max-width:900px){
            .dashboard-grid{ grid-template-columns:repeat(2,1fr); }
        }
        @media (max-width:600px){
            .dashboard-grid{ grid-template-columns:1fr; }
            .nav-links{ display:none; }
        }
    </style>
</head>
<body class="<?php echo 'theme-'.htmlspecialchars($applied_theme); ?>"
      <?php
        $inline = '';
        if ($applied_theme === 'custom') {
            $inline .= "--accent: ".htmlspecialchars($btn_color).";";
            $inline .= "--header: ".htmlspecialchars($header_color).";";
            $inline .= "--text: ".htmlspecialchars($text_color).";";
        } else {
            if (!empty($btn_color)) $inline .= "--accent: ".htmlspecialchars($btn_color).";";
            if (!empty($header_color)) $inline .= "--header: ".htmlspecialchars($header_color).";";
            if (!empty($text_color)) $inline .= "--text: ".htmlspecialchars($text_color).";";
        }
        if (!empty($bg_url)) $inline .= "background-image:url('".htmlspecialchars($bg_url)."');";
        if ($inline) echo ' style="'.$inline.'"';
      ?>>

    <!-- Header -->
    <header class="main-header">
        <div class="container">
            <nav class="navbar">
                <a href="#" class="logo" onclick="showPage('dashboard')">
                    <span>📁</span>
                    ProjectFolio
                </a>

                <div class="nav-links">
                    <a href="../HTML/index.php" class="nav-link active" onclick="showPage('dashboard')">Mi Espacio</a>
                    <a href="../HTML/Explorar.php" class="nav-link" onclick="showPage('explore')">Explorar</a>
                    <a href="../HTML/Equipos.php" class="nav-link" onclick="showPage('teams')">Equipos</a>
                    <a href="../HTML/Calificaciones.php" class="nav-link" onclick="showPage('statistics')">Estadísticas</a>
                </div>

                <div class="user-menu">
                    <a href="../DieñoEli/login.html" class="btn">Cerrar sesion</a>
                    <div style="display:flex;align-items:center;gap:.6rem;">
                        <div style="text-align:right;">
                            <div style="font-size:.85rem;"><?php echo htmlspecialchars($usuario_correo); ?></div>
                            <div style="font-size:.75rem;color:var(--muted);">Bienvenido</div>
                        </div>
                        <div class="user-avatar"><?php echo strtoupper(substr($usuario_correo,0,2)); ?></div>
                    </div>
                </div>
            </nav>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-content">
        <div class="container">
            <!-- Dashboard Page -->
            <div id="dashboard" class="page active">
                <div class="section-header">
                    <div>
                        <h2 class="section-title">Mi Espacio</h2>
                        <p style="margin:0;color:var(--muted);">Bienvenido de vuelta, <?php echo htmlspecialchars(explode('@',$usuario_correo)[0]); ?></p>
                    </div>
                    <div style="display:flex;gap:.6rem;align-items:center;">
                        <a href="../HTML/crear_proyecto.php" class="btn">➕ Nuevo Proyecto</a>
                        <a href="../HTML/perfil.php" class="btn btn-outline">Mi Perfil</a>
                    </div>
                </div>

                <div class="dashboard-grid">
                    <div class="dashboard-card">
                        <div class="card-header">
                            <div class="card-icon">📊</div>
                            <h3 class="card-title">Estadísticas</h3>
                        </div>
                        <div class="stat-number"><?php echo count($proyectos); ?></div>
                        <div class="stat-label">Proyectos creados</div>
                    </div>

                    <div class="dashboard-card">
                        <div class="card-header">
                            <div class="card-icon">👥</div>
                            <h3 class="card-title">Actividades hoy</h3>
                        </div>
                        <div class="stat-number"><?php echo $avance_dia; ?></div>
                        <div class="stat-label">Tareas activas hoy</div>
                    </div>

                    <div class="dashboard-card">
                        <div class="card-header">
                            <div class="card-icon">⭐</div>
                            <h3 class="card-title">Semana</h3>
                        </div>
                        <div class="stat-number"><?php echo $avance_semana; ?></div>
                        <div class="stat-label">Tareas esta semana</div>
                    </div>

                    <div class="dashboard-card">
                        <div class="card-header">
                            <div class="card-icon">👁️</div>
                            <h3 class="card-title">Últimos 6 meses</h3>
                        </div>
                        <div class="stat-number"><?php echo $avance_semestre; ?></div>
                        <div class="stat-label">Tareas en semestre</div>
                    </div>
                </div>

                <div class="section-header" style="margin-top:1.2rem;">
                    <h3 class="section-title">Proyectos Recientes</h3>
                    <a href="#" class="btn btn-outline" onclick="showPage('explore')">Ver Todos</a>
                </div>

                <div class="projects-grid">
                    <?php if (count($avance_proyectos) === 0): ?>
                        <div class="project-card">
                            <p>No tienes proyectos todavía. <a href="../HTML/crear_proyecto.php">Crea el primero</a></p>
                        </div>
                    <?php else: ?>
                        <?php foreach($avance_proyectos as $repo): ?>
                            <?php
                                // obtener maestro e integrantes para este proyecto
                                $maestro_nombre = 'Sin maestro asignado';
                                $integrantes = [];
                                $conn_repo = new mysqli("localhost", "root", "", "promanage");
                                if (!$conn_repo->connect_error) {
                                    // maestro
                                    if (!empty($repo['maestro_id'])) {
                                        $stmtM = $conn_repo->prepare("SELECT nombre FROM maestros WHERE id = ? LIMIT 1");
                                        if ($stmtM) {
                                            $stmtM->bind_param("i", $repo['maestro_id']);
                                            $stmtM->execute();
                                            $resM = $stmtM->get_result();
                                            if ($r = $resM->fetch_assoc()) $maestro_nombre = $r['nombre'];
                                            $stmtM->close();
                                        }
                                    } else {
                                        // try via proyectos.maestro_id if not present (defensive)
                                        $stmtM2 = $conn_repo->prepare("SELECT m.nombre FROM maestros m JOIN proyectos p ON p.maestro_id = m.id WHERE p.id = ? LIMIT 1");
                                        if ($stmtM2) {
                                            $stmtM2->bind_param("i", $repo['id']);
                                            $stmtM2->execute();
                                            $r2 = $stmtM2->get_result()->fetch_assoc();
                                            if ($r2) $maestro_nombre = $r2['nombre'];
                                            $stmtM2->close();
                                        }
                                    }
                                    // integrantes
                                    $stmtI = $conn_repo->prepare("
                                        SELECT u.id, u.nombre, u.correo
                                        FROM integrantes i
                                        JOIN usuarios u ON i.usuario_id = u.id
                                        WHERE i.proyecto_id = ?
                                        ORDER BY u.nombre ASC
                                    ");
                                    if ($stmtI) {
                                        $stmtI->bind_param("i", $repo['id']);
                                        $stmtI->execute();
                                        $resI = $stmtI->get_result();
                                        while ($u = $resI->fetch_assoc()) $integrantes[] = $u;
                                        $stmtI->close();
                                    }
                                }
                                if (isset($conn_repo) && !$conn_repo->connect_error) $conn_repo->close();
                            ?>
                            <div class="project-card">
                                <div class="project-header">
                                    <span class="project-status <?php echo $repo['pendientes'] == 0 ? 'status-completed' : 'status-in-progress'; ?>">
                                        <?php echo $repo['pendientes'] == 0 ? 'Completado' : 'En Progreso'; ?>
                                    </span>
                                    <h3 class="project-title"><?php echo htmlspecialchars($repo['nombre']); ?></h3>
                                    <p class="project-description"><?php echo htmlspecialchars($repo['descripcion']); ?></p>
                                    <div class="project-meta" style="margin-top:.6rem; color:var(--muted); font-size:.9rem;">
                                        <span>Completadas: <?php echo $repo['completadas']; ?></span> •
                                        <span>Pendientes: <?php echo $repo['pendientes']; ?></span> •
                                        <span>Últ. commit: <?php echo htmlspecialchars($repo['ultimo_commit']); ?></span>
                                    </div>
                                </div>

                                <div style="margin-top:.8rem;">
                                    <p style="margin:.2rem 0;"><strong>Maestro:</strong> <?php echo htmlspecialchars($maestro_nombre); ?></p>
                                    <p style="margin:.2rem 0;"><strong>Integrantes (<?php echo count($integrantes); ?>):</strong></p>
                                    <?php if (count($integrantes) === 0): ?>
                                        <p style="color:var(--muted);margin:0">No hay integrantes agregados.</p>
                                    <?php else: ?>
                                        <ul style="margin:.4rem 0 0 1rem; padding:0; color:var(--text);">
                                            <?php foreach($integrantes as $int): ?>
                                                <li style="margin:.15rem 0;"><?php echo htmlspecialchars($int['nombre']); ?> <?php if (!empty($int['correo'])): ?><small style="color:var(--muted)"> — <?php echo htmlspecialchars($int['correo']); ?></small><?php endif; ?> <?php if ((int)$int['id'] === (int)$usuario_id) echo '<strong>(tú)</strong>'; ?></li>
                                            <?php endforeach; ?>
                                        </ul>
                                    <?php endif; ?>
                                </div>

                                <div class="repo-actions">
                                     <a href="ver_proyecto.php?id=<?php echo $repo['id']; ?>">Ver</a>
                                     <a href="editar_proyecto.php?id=<?php echo $repo['id']; ?>">Editar</a>
                                     <a href="eliminar_proyecto.php?id=<?php echo $repo['id']; ?>">Eliminar</a>
                                 </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Other pages (explore, teams, favorites, statistics, new-project, profile, settings, privacy, help)
                 kept as static placeholders from your template — we won't duplicate them here for brevity,
                 but you can keep the same HTML from your original template below if you want. -->
            <?php /* If you want the rest of the pages exactly as in your mockup, paste them here. */ ?>
        </div>
    </main>

    <!-- Footer -->
    <footer class="main-footer" style="margin-top:2rem;padding:1rem 0;background:transparent;">
        <div class="container">
            <div style="display:flex;gap:2rem;flex-wrap:wrap;align-items:flex-start;justify-content:space-between;">
                <div>
                    <h3 style="margin:0">ProjectFolio</h3>
                    <p style="margin:.2rem 0 .8rem 0;color:var(--muted)">Tu espacio personal para proyectos innovadores</p>
                </div>
                <div style="color:var(--muted)">© <?php echo date('Y'); ?> ProjectFolio</div>
            </div>
        </div>
    </footer>

    <script>
        // Navegación entre páginas (simple)
        function showPage(pageId) {
            document.querySelectorAll('.page').forEach(page => page.classList.remove('active'));
            const el = document.getElementById(pageId);
            if (el) el.classList.add('active');

            document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
            document.querySelectorAll('.nav-link').forEach(link => {
                if (link.textContent.trim() === (pageId === 'dashboard' ? 'Mi Espacio' : link.textContent.trim())) {
                    // keep previous mapping simple; you can expand mapping if needed
                }
            });
            return false;
        }

        // Splash de acceso (opcional)
        function showSuccessSplash() {
            // same splash you provided (kept minimal)
            const splashOverlay = document.createElement('div');
            splashOverlay.style.cssText = `
                position: fixed; top:0; left:0; width:100%; height:100%; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                display:flex; align-items:center; justify-content:center; z-index:10000;
            `;
            splashOverlay.innerHTML = `
                <div style="text-align:center;color:white;">
                    <h1>Accediendo</h1>
                    <p>Cargando tu perfil...</p>
                </div>
            `;
            document.body.appendChild(splashOverlay);
            setTimeout(()=> window.location.href = 'dash.html', 1500);
        }
    </script>
</body>
</html>