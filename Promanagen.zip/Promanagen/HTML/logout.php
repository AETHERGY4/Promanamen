<?php
// logout.php
session_start();

// Limpiar datos de sesión específicos y destruir sesión
// Borra verificación de maestro y otros datos sensibles
unset($_SESSION['maestro_verificado']);
unset($_SESSION['maestro']);
unset($_SESSION['usuario_id']);
unset($_SESSION['usuario_correo']);

// Regenerate session id and destroy
session_regenerate_id(true);
$_SESSION = [];
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
session_destroy();

// Redirigir a la página de inicio (ajusta la ruta si hace falta)
header("Location: ../DiseñoEli/login.html");
exit;