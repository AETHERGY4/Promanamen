<?php
session_start();
if (!isset($_SESSION['usuario_id'])) header("Location: Inicio.html");

$usuario_id = $_SESSION['usuario_id'];
$usuario_correo = $_SESSION['usuario_correo'] ?? 'Usuario';

if (!isset($_SESSION['usuario_id'])) header("Location: login.html");

$usuario_id = $_SESSION['usuario_id'];
$usuario_correo = $_SESSION['usuario_correo'];

// --- Obtener tema y personalizaciones del usuario ---
$applied_theme = 'dark';
$applied_color = '#238636';
$bg_url = null;
$btn_color = '#238636';
$header_color = '#161b22';
$text_color = '#c9d1d9';

$conn_theme = new mysqli("localhost", "root", "", "promanage");
if (!$conn_theme->connect_error) {
    $stmt_t = $conn_theme->prepare("SELECT theme, custom_color, bg_url, btn_color, header_color, text_color FROM usuarios WHERE id=? LIMIT 1");
    if ($stmt_t) {
        $stmt_t->bind_param("i",$usuario_id);
        $stmt_t->execute();
        $res_t = $stmt_t->get_result()->fetch_assoc();
        if ($res_t) {
            $applied_theme = in_array($res_t['theme'], ['dark','light','custom']) ? $res_t['theme'] : 'dark';
            $applied_color = preg_match('/^#[0-9A-Fa-f]{6}$/', $res_t['custom_color'] ?? '') ? $res_t['custom_color'] : $applied_color;
            $bg_url = !empty($res_t['bg_url']) ? $res_t['bg_url'] : null;
            $btn_color = preg_match('/^#[0-9A-Fa-f]{6}$/', $res_t['btn_color'] ?? '') ? $res_t['btn_color'] : $btn_color;
            $header_color = preg_match('/^#[0-9A-Fa-f]{6}$/', $res_t['header_color'] ?? '') ? $res_t['header_color'] : $header_color;
            $text_color = preg_match('/^#[0-9A-Fa-f]{6}$/', $res_t['text_color'] ?? '') ? $res_t['text_color'] : $text_color;
        }
        $stmt_t->close();
    }
}
$conn_theme->close();

$uploadDir = __DIR__ . '/../../Promanagen/uploads/backgrounds/'; // ajusta si tu estructura es distinta
$publicUploadDir = '/Promanagen/uploads/backgrounds/'; // ruta pública usada en HTML

// Asegurar que exista la carpeta de uploads
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

$conn = new mysqli("localhost", "root", "", "promanage");
if ($conn->connect_error) die("Conexión fallida: " . $conn->connect_error);

// Manejar POST (guardar cambios y subir/eliminar fondo si existe)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $ubicacion = trim($_POST['ubicacion'] ?? '');
    $bio = trim($_POST['bio'] ?? '');
    $theme = in_array($_POST['theme'] ?? '', ['dark','light','custom']) ? $_POST['theme'] : 'dark';

    // Validar colores hex
    $btn_color = preg_match('/^#[0-9A-Fa-f]{6}$/', $_POST['btn_color'] ?? '') ? $_POST['btn_color'] : null;
    $header_color = preg_match('/^#[0-9A-Fa-f]{6}$/', $_POST['header_color'] ?? '') ? $_POST['header_color'] : null;
    $text_color = preg_match('/^#[0-9A-Fa-f]{6}$/', $_POST['text_color'] ?? '') ? $_POST['text_color'] : null;

    // Primero obtener bg_url actual para posible borrado
    $stmtOld = $conn->prepare("SELECT bg_url FROM usuarios WHERE id=? LIMIT 1");
    $stmtOld->bind_param("i", $usuario_id);
    $stmtOld->execute();
    $r = $stmtOld->get_result()->fetch_assoc();
    $stmtOld->close();
    $existingBg = !empty($r['bg_url']) ? $r['bg_url'] : null;

    // Manejar eliminación explícita de fondo
    $removeBgRequested = isset($_POST['remove_bg']) && $_POST['remove_bg'] == '1';
    if ($removeBgRequested && $existingBg) {
        $oldPath = $_SERVER['DOCUMENT_ROOT'] . $existingBg;
        if (is_file($oldPath)) @unlink($oldPath);
        $existingBg = null; // mark removed
    }

    // Manejar subida de fondo (opcional) — si suben archivo se reemplaza
    $bg_url_db = null;
    if (!empty($_FILES['bg_file']['name'])) {
        $file = $_FILES['bg_file'];
        if ($file['error'] === UPLOAD_ERR_OK) {
            if ($file['size'] > 3 * 1024 * 1024) {
                $error = "El archivo es demasiado grande (máx 3MB).";
            } else {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $mime = finfo_file($finfo, $file['tmp_name']);
                finfo_close($finfo);
                $allowed = ['image/jpeg','image/png','image/webp'];
                if (!in_array($mime, $allowed)) {
                    $error = "Formato no permitido. Usa JPG, PNG o WEBP.";
                } else {
                    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
                    $filename = 'bg_u' . $usuario_id . '_' . time() . '.' . $ext;
                    $dest = $uploadDir . $filename;
                    if (move_uploaded_file($file['tmp_name'], $dest)) {
                        $bg_url_db = $publicUploadDir . $filename;
                        // eliminar anterior
                        if (!empty($existingBg)) {
                            $oldPath = $_SERVER['DOCUMENT_ROOT'] . $existingBg;
                            if (is_file($oldPath)) @unlink($oldPath);
                        }
                    } else {
                        $error = "No se pudo mover el archivo subido.";
                    }
                }
            }
        } else {
            $error = "Error al subir archivo (código {$file['error']}).";
        }
    }

    // Si el usuario solicitó eliminar y no subió nuevo fondo, dejamos bg_url vacío
    if ($removeBgRequested && !$bg_url_db) {
        $bg_url_db = ''; // significa borrar en DB
    }

    // Construir UPDATE dinámico
    $fields = "nombre=?, telefono=?, ubicacion=?, bio=?, theme=?";
    $types = "sssss";
    $values = [$nombre, $telefono, $ubicacion, $bio, $theme];

    if ($btn_color !== null) { $fields .= ", btn_color=?"; $types .= "s"; $values[] = $btn_color; }
    if ($header_color !== null) { $fields .= ", header_color=?"; $types .= "s"; $values[] = $header_color; }
    if ($text_color !== null) { $fields .= ", text_color=?"; $types .= "s"; $values[] = $text_color; }
    if ($bg_url_db !== null) { $fields .= ", bg_url=?"; $types .= "s"; $values[] = ($bg_url_db === '' ? null : $bg_url_db); /* null to set NULL in DB */ }

    $values[] = $usuario_id;
    $types .= "i";

    $sql = "UPDATE usuarios SET $fields WHERE id=?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) die("Error prepare: " . $conn->error);

    // bind_param — PHP tratará nulls correctamente si usamos variables PHP null
    $stmt->bind_param($types, ...$values);
    $stmt->execute();
    $stmt->close();

    // actualizar sesión (opcional)
    $_SESSION['theme'] = $theme;
    if ($btn_color !== null) $_SESSION['btn_color'] = $btn_color;
    if ($header_color !== null) $_SESSION['header_color'] = $header_color;
    if ($text_color !== null) $_SESSION['text_color'] = $text_color;
    if ($bg_url_db) $_SESSION['bg_url'] = $bg_url_db;
    if ($bg_url_db === '') unset($_SESSION['bg_url']); // si borrado

    header("Location: perfil.php");
    exit;
}

// Traer datos actuales
$stmt = $conn->prepare("SELECT nombre, telefono, ubicacion, bio, theme, custom_color, bg_url, btn_color, header_color, text_color FROM usuarios WHERE id=?");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$usuario = $result->fetch_assoc() ?: [];
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Perfil de <?php echo htmlspecialchars($usuario_correo); ?></title>
<link rel="stylesheet" href="/Promanagen/CSS/repositorio.css">
    <style>
        :root{
          --bg: #0d1117; --surface: #161b22; --text: #c9d1d9; --accent: <?php echo htmlspecialchars($applied_color); ?>; --header: <?php echo htmlspecialchars($header_color); ?>; --muted: #8b949e;
        }
        body.theme-light { --bg: #ffffff; --surface: #f6f8fa; --text: #0b0b0b; --accent: #0b5cff; --header: #e6eefc; --muted: #6b7280; }
        body.theme-custom { --bg: #ffffff; --surface: #f6f8fa; --text: #0b0b0b; --muted: #6b7280; }

        body {
          background-color: var(--bg);
          color: var(--text);
          margin:0; padding:0; font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
          background-size: cover; background-position: center; background-attachment: fixed; position: relative;
        }
        .container{ max-width:1100px; margin:0 auto; padding:1rem; }
        .main-header{ background:var(--header); padding:0.8rem 0; border-bottom:1px solid rgba(255,255,255,0.03); }
        .navbar{ display:flex; align-items:center; justify-content:space-between; gap:1rem; }
        .logo{ color:var(--text); text-decoration:none; font-weight:700; font-size:1.1rem; display:flex; gap:.5rem; align-items:center; }
        .nav-links{ display:flex; gap:.6rem; align-items:center; }
        .nav-link{ color:var(--muted); text-decoration:none; padding:.4rem .6rem; border-radius:6px; font-size:.95rem; }
        .nav-link.active{ color:var(--text); background:rgba(255,255,255,0.02); }
        .user-menu{ display:flex; gap:.6rem; align-items:center; }
        .btn{ background:var(--accent); color:#fff; padding:.45rem .7rem; border-radius:8px; text-decoration:none; }
        .btn-outline{ border:1px solid rgba(255,255,255,0.06); padding:.35rem .6rem; color:var(--text); background:transparent; border-radius:6px; text-decoration:none; }
        .user-avatar{ width:36px; height:36px; background:rgba(255,255,255,0.06); display:flex; align-items:center; justify-content:center; border-radius:6px; color:var(--text); font-weight:700; }
        .main-content{ padding:1rem 0; }
        .section-header{ display:flex; justify-content:space-between; align-items:center; gap:1rem; margin:1rem 0; }
        .section-title{ margin:0; color:var(--text); }
        .dashboard-grid{ display:grid; grid-template-columns:repeat(4,1fr); gap:1rem; margin-bottom:1rem; }
        .dashboard-card{ background:var(--surface); padding:1rem; border-radius:10px; text-align:center; }
        .card-header{ display:flex; gap:.6rem; align-items:center; justify-content:center; }
        .card-icon{ font-size:1.6rem; }
        .stat-number{ font-size:1.6rem; font-weight:700; margin-top:.6rem; }
        .projects-grid{ display:grid; grid-template-columns:repeat(auto-fit,minmax(320px,1fr)); gap:1rem; }
        .project-card{ background:var(--surface); padding:1rem; border-radius:10px; }
        .project-status{ font-size:.8rem; padding:.2rem .5rem; border-radius:6px; display:inline-block; margin-bottom:.6rem; }
        .status-completed{ background:rgba(34,197,94,0.12); color:#a7f3d0; }
        .status-in-progress{ background:rgba(59,130,246,0.08); color:#bfdbfe; }
        .repo-actions a{ margin-right:.5rem; color:var(--text); text-decoration:none; background:var(--accent); padding:.3rem .5rem; border-radius:6px; font-size:.85rem; }
        .repositorio { background:var(--surface); padding:15px; margin:15px 0; border-radius:10px; }
        /* mobile adjustments */
        @media (max-width:900px){
            .dashboard-grid{ grid-template-columns:repeat(2,1fr); }
        }
        @media (max-width:600px){
            .dashboard-grid{ grid-template-columns:1fr; }
            .nav-links{ display:none; }
        }
    </style>
</head>
<body>
<header class="header">
    <div class="user-menu">
            <div style="display:flex;align-items:center;gap:.6rem;">
                <div style="text-align:right;">
                    <div style="font-size:.85rem;"><?php echo htmlspecialchars($usuario_correo); ?></div>
                    <div style="font-size:.75rem;color:var(--muted);">Bienvenido</div>
                </div>
                <div class="user-avatar"><?php echo strtoupper(substr($usuario_correo,0,2)); ?></div>
            </div>
        </div>
    <div class="nav-links">
        <a href="../HTML/index.php" class="nav-link active" onclick="showPage('dashboard')">Mi Espacio</a>
        <a href="../HTML/Explorar.php" class="nav-link" onclick="showPage('explore')">Explorar</a>
        <a href="../HTML/Equipos.php" class="nav-link" onclick="showPage('teams')">Equipos</a>
        <a href="../HTML/Calificaciones.php" class="nav-link" onclick="showPage('statistics')">Estadísticas</a>
    </div>
    <div class="header-right">
        <a href="/Promanagen/HTML/index.php" class="btn">Volver</a>
    </div>
</header>

<main class="container">
    <div class="repositorio">
        <h2>Información del Perfil</h2>
        <form method="post" enctype="multipart/form-data">
            <label>Nombre:</label><br>
            <input type="text" name="nombre" value="<?php echo htmlspecialchars($usuario['nombre'] ?? ''); ?>" class="input-field"><br><br>

            <label>Teléfono:</label><br>
            <input type="text" name="telefono" value="<?php echo htmlspecialchars($usuario['telefono'] ?? ''); ?>" class="input-field"><br><br>

            <label>Ubicación:</label><br>
            <input type="text" name="ubicacion" value="<?php echo htmlspecialchars($usuario['ubicacion'] ?? ''); ?>" class="input-field"><br><br>

            <label>Bio:</label><br>
            <textarea name="bio" class="input-field"><?php echo htmlspecialchars($usuario['bio'] ?? ''); ?></textarea><br><br>

            <h3>Preferencias de tema</h3>
            <div class="theme-row">
                <label><input type="radio" name="theme" value="dark" <?php echo (($usuario['theme'] ?? 'dark') === 'dark') ? 'checked' : ''; ?>> Oscuro</label>
                <label><input type="radio" name="theme" value="light" <?php echo (($usuario['theme'] ?? '') === 'light') ? 'checked' : ''; ?>> Claro</label>
                <label><input type="radio" name="theme" value="custom" <?php echo (($usuario['theme'] ?? '') === 'custom') ? 'checked' : ''; ?>> Personalizado</label>
            </div>

            <div class="mb-3">
                <label for="btn_color">Color de botones</label><br>
                <input type="color" id="btn_color" name="btn_color" value="<?php echo htmlspecialchars($usuario['btn_color'] ?? '#238636'); ?>">
                <span class="color-preview" id="previewBtn" style="background: <?php echo htmlspecialchars($usuario['btn_color'] ?? '#238636'); ?>"></span>
            </div>

            <div class="mb-3">
                <label for="header_color">Color del header</label><br>
                <input type="color" id="header_color" name="header_color" value="<?php echo htmlspecialchars($usuario['header_color'] ?? '#161b22'); ?>">
                <span class="color-preview" id="previewHeader" style="background: <?php echo htmlspecialchars($usuario['header_color'] ?? '#161b22'); ?>"></span>
            </div>

            <div class="mb-3">
                <label for="text_color">Color del texto</label><br>
                <input type="color" id="text_color" name="text_color" value="<?php echo htmlspecialchars($usuario['text_color'] ?? '#c9d1d9'); ?>">
                <span class="color-preview" id="previewText" style="background: <?php echo htmlspecialchars($usuario['text_color'] ?? '#c9d1d9'); ?>"></span>
            </div>

            <div class="mb-3">
                <label for="bg_file">Fondo de página (opcional) — JPG / PNG / WEBP (máx 3MB)</label><br>
                <input type="file" id="bg_file" name="bg_file" accept="image/*"><br>

                <?php if(!empty($usuario['bg_url'])): ?>
                    <div class="bg-preview" id="bgPreview" style="background-image:url('<?php echo htmlspecialchars($usuario['bg_url']); ?>')"></div>
                    <div class="remove-row">
                        <label><input type="checkbox" name="remove_bg" value="1"> Eliminar fondo actual</label>
                        <span class="note">Marca y guarda para quitar el fondo del perfil.</span>
                    </div>
                <?php else: ?>
                    <div class="note">No has subido un fondo aún.</div>
                <?php endif; ?>
            </div>

            <br>
            <button type="submit" class="btn">Guardar Cambios</button>
        </form>
    </div>
</main>

<script>
// previews
const btnColor = document.getElementById('btn_color');
const headerColor = document.getElementById('header_color');
const textColor = document.getElementById('text_color');
const previewBtn = document.getElementById('previewBtn');
const previewHeader = document.getElementById('previewHeader');
const previewText = document.getElementById('previewText');
btnColor?.addEventListener('input', e => previewBtn.style.background = e.target.value);
headerColor?.addEventListener('input', e => previewHeader.style.background = e.target.value);
textColor?.addEventListener('input', e => previewText.style.background = e.target.value);

// preview local del fondo antes de subir
const bgFile = document.getElementById('bg_file');
const bgPreviewEl = document.getElementById('bgPreview');
bgFile?.addEventListener('change', e=>{
    const f = e.target.files[0];
    if(!f) return;
    if(f.size > 3*1024*1024){ alert('El archivo supera 3MB'); bgFile.value=''; return; }
    const reader = new FileReader();
    reader.onload = function(ev){
        if(bgPreviewEl) bgPreviewEl.style.backgroundImage = `url('${ev.target.result}')`;
        else {
            const d = document.createElement('div');
            d.className = 'bg-preview';
            d.style.backgroundImage = `url('${ev.target.result}')`;
            bgFile.parentNode.appendChild(d);
        }
    };
    reader.readAsDataURL(f);
});
</script>
</body>
</html>