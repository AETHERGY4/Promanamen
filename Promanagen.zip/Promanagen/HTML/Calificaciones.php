<?php
session_start();
if(!isset($_SESSION['usuario_id'])){
    header("Location: ../HTML/Inicio.html");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$usuario_correo = $_SESSION['usuario_correo'] ?? 'Usuario';

$conn = new mysqli("localhost","root","", "promanage");
if($conn->connect_error) die("Error de conexión: ".$conn->connect_error);

// Traer proyectos del alumno
$stmt = $conn->prepare("SELECT * FROM proyectos WHERE usuario_id=?");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$proyectos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Mis Estadísticas</title>
<link rel="stylesheet" href="/Promanagen/CSS/repositorio.css">
    <style>
        :root{
          --bg: #0d1117; --surface: #161b22; --text: #c9d1d9; --accent: <?php echo htmlspecialchars($applied_color); ?>; --header: <?php echo htmlspecialchars($header_color); ?>; --muted: #8b949e;
        }
        body.theme-light { --bg: #ffffff; --surface: #f6f8fa; --text: #0b0b0b; --accent: #0b5cff; --header: #e6eefc; --muted: #6b7280; }
        body.theme-custom { --bg: #ffffff; --surface: #f6f8fa; --text: #0b0b0b; --muted: #6b7280; }

        body {
          background-color: var(--bg);
          color: var(--text);
          margin:0; padding:0; font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
          background-size: cover; background-position: center; background-attachment: fixed; position: relative;
        }
        .container{ max-width:1100px; margin:0 auto; padding:1rem; }
        .main-header{ background:var(--header); padding:0.8rem 0; border-bottom:1px solid rgba(255,255,255,0.03); }
        .navbar{ display:flex; align-items:center; justify-content:space-between; gap:1rem; }
        .logo{ color:var(--text); text-decoration:none; font-weight:700; font-size:1.1rem; display:flex; gap:.5rem; align-items:center; }
        .nav-links{ display:flex; gap:.6rem; align-items:center; }
        .nav-link{ color:var(--muted); text-decoration:none; padding:.4rem .6rem; border-radius:6px; font-size:.95rem; }
        .nav-link.active{ color:var(--text); background:rgba(255,255,255,0.02); }
        .user-menu{ display:flex; gap:.6rem; align-items:center; }
        .btn{ background:var(--accent); color:#fff; padding:.45rem .7rem; border-radius:8px; text-decoration:none; }
        .btn-outline{ border:1px solid rgba(255,255,255,0.06); padding:.35rem .6rem; color:var(--text); background:transparent; border-radius:6px; text-decoration:none; }
        .user-avatar{ width:36px; height:36px; background:rgba(255,255,255,0.06); display:flex; align-items:center; justify-content:center; border-radius:6px; color:var(--text); font-weight:700; }
        .main-content{ padding:1rem 0; }
        .section-header{ display:flex; justify-content:space-between; align-items:center; gap:1rem; margin:1rem 0; }
        .section-title{ margin:0; color:var(--text); }
        .dashboard-grid{ display:grid; grid-template-columns:repeat(4,1fr); gap:1rem; margin-bottom:1rem; }
        .dashboard-card{ background:var(--surface); padding:1rem; border-radius:10px; text-align:center; }
        .card-header{ display:flex; gap:.6rem; align-items:center; justify-content:center; }
        .card-icon{ font-size:1.6rem; }
        .stat-number{ font-size:1.6rem; font-weight:700; margin-top:.6rem; }
        .projects-grid{ display:grid; grid-template-columns:repeat(auto-fit,minmax(320px,1fr)); gap:1rem; }
        .project-card{ background:var(--surface); padding:1rem; border-radius:10px; }
        .project-status{ font-size:.8rem; padding:.2rem .5rem; border-radius:6px; display:inline-block; margin-bottom:.6rem; }
        .status-completed{ background:rgba(34,197,94,0.12); color:#a7f3d0; }
        .status-in-progress{ background:rgba(59,130,246,0.08); color:#bfdbfe; }
        .repo-actions a{ margin-right:.5rem; color:var(--text); text-decoration:none; background:var(--accent); padding:.3rem .5rem; border-radius:6px; font-size:.85rem; }
        .repositorio { background:var(--surface); padding:15px; margin:15px 0; border-radius:10px; }
        /* mobile adjustments */
        @media (max-width:900px){
            .dashboard-grid{ grid-template-columns:repeat(2,1fr); }
        }
        @media (max-width:600px){
            .dashboard-grid{ grid-template-columns:1fr; }
            .nav-links{ display:none; }
        }
    </style>
</head>
<body>
<header class="header">
    <div class="user-menu">
            <div style="display:flex;align-items:center;gap:.6rem;">
                <div style="text-align:right;">
                    <div style="font-size:.85rem;"><?php echo htmlspecialchars($usuario_correo); ?></div>
                    <div style="font-size:.75rem;color:var(--muted);">Bienvenido</div>
                </div>
                <div class="user-avatar"><?php echo strtoupper(substr($usuario_correo,0,2)); ?></div>
            </div>
        </div>
    <div class="nav-links">
        <a href="../HTML/index.php" class="nav-link active" onclick="showPage('dashboard')">Mi Espacio</a>
        <a href="../HTML/Explorar.php" class="nav-link" onclick="showPage('explore')">Explorar</a>
        <a href="../HTML/Equipos.php" class="nav-link" onclick="showPage('teams')">Equipos</a>
        <a href="../HTML/Calificaciones.php" class="nav-link" onclick="showPage('statistics')">Estadísticas</a>
    </div>
    <div class="header-right">
        <a href="/Promanagen/HTML/index.php" class="btn">Volver</a>
    </div>
</header>
<body>
<div class="container">
    <h2>Mis Estadísticas</h2>
    <?php if(empty($proyectos)): ?>
        <p>No tienes proyectos todavía.</p>
    <?php else: ?>
        <?php foreach($proyectos as $p): ?>
            <div class="repositorio">
                <h3><?php echo htmlspecialchars($p['nombre']); ?></h3>
                <p><?php echo htmlspecialchars($p['descripcion']); ?></p>
                <?php if($p['calificacion'] !== null): ?>
                    <p><strong>Calificación:</strong> <?php echo $p['calificacion']; ?> / 100</p>
                    <p><strong>Comentarios del maestro:</strong> <?php echo htmlspecialchars($p['comentario']); ?></p>
                <?php else: ?>
                    <p>Aún no ha sido calificado por el maestro.</p>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
</body>
</html>
<?php $conn->close(); ?>