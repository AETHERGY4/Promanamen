<?php
session_start();
if (!isset($_SESSION['usuario_id'])) header("Location: ../HTML/Inicio.html");

$usuario_correo = $_SESSION['usuario_correo'] ?? 'Usuario';

// Conexión BD
$conn = new mysqli("localhost","root","","promanage");
if ($conn->connect_error) die("Conexión fallida: ".$conn->connect_error);

// --- Obtener todos los proyectos ---
$projects = [];
$res = $conn->query("SELECT id, nombre, descripcion FROM proyectos ORDER BY id DESC");
while($row = $res->fetch_assoc()) $projects[] = $row;
$res->free();

// --- Revisar si la tabla archivos tiene columna actividad_id ---
$archivo_tiene_actividad_col = false;
$res_col = $conn->query("SHOW COLUMNS FROM archivos LIKE 'actividad_id'");
if ($res_col && $res_col->num_rows > 0) $archivo_tiene_actividad_col = true;
if ($res_col) $res_col->free();

// --- Traer archivos de todos los proyectos ---
$archivos_por_proyecto = [];
if ($archivo_tiene_actividad_col) {
    $stmt = $conn->prepare("SELECT proyecto_id, nombre_archivo, ruta FROM archivos ORDER BY fecha_subida DESC");
    $stmt->execute();
    $res = $stmt->get_result();
    while ($f = $res->fetch_assoc()) {
        $pid = (int)$f['proyecto_id'];
        $archivos_por_proyecto[$pid][] = $f;
    }
    $stmt->close();
} else {
    $stmt = $conn->prepare("SELECT proyecto_id, nombre_archivo, ruta FROM archivos ORDER BY fecha_subida DESC");
    $stmt->execute();
    $res = $stmt->get_result();
    while ($f = $res->fetch_assoc()) {
        $pid = (int)$f['proyecto_id'];
        $archivos_por_proyecto[$pid][] = $f;
    }
    $stmt->close();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Explorar - ProjectFolio</title>
<link rel="stylesheet" href="/Promanagen/CSS/repositorio.css">
<style>
body { background:#0d1117; color:#c9d1d9; font-family: system-ui, -apple-system, "Segoe UI", Roboto, Arial; margin:0; }
.container{ max-width:1100px; margin:0 auto; padding:1rem; }
.main-header{ background:#161b22; padding:0.8rem 0; border-bottom:1px solid rgba(255,255,255,0.03); }
.navbar{ display:flex; justify-content:space-between; align-items:center; padding:0 1rem; }
.logo{ color:#c9d1d9; font-weight:700; text-decoration:none; }
.nav-links{ display:flex; gap:.6rem; align-items:center; }
.nav-link{ color:#8b949e; text-decoration:none; padding:.4rem .6rem; border-radius:6px; }
.nav-link.active{ color:#c9d1d9; background:rgba(255,255,255,0.02); }
.projects-grid{ display:grid; grid-template-columns:repeat(auto-fit,minmax(320px,1fr)); gap:1rem; margin-top:1rem; }
.project-card{ background:#161b22; padding:1rem; border-radius:10px; }
.project-title{ font-size:1.1rem; margin:0 0 .3rem 0; }
.project-description{ font-size:.9rem; margin:0 0 .5rem 0; color:#8b949e; }
.project-files{ margin-top:.5rem; }
.file-link{ display:block; font-size:.85rem; color:#c9d1d9; text-decoration:none; margin:.15rem 0; }
.file-link:hover{ text-decoration:underline; }
@media(max-width:700px){ .projects-grid{ grid-template-columns:1fr; } }
</style>
</head>
<body>
    <header class="main-header">
        <div class="container">
            <nav class="navbar">
                <a href="#" class="logo" onclick="showPage('dashboard')">
                    <span>📁</span>
                    ProjectFolio
                </a>
                <a href="../HTML/index.php" class="btn">Volver</a>

                <div class="nav-links">
                    <a href="../HTML/index.php" class="nav-link active" onclick="showPage('dashboard')">Mi Espacio</a>
                    <a href="../HTML/Explorar.php" class="nav-link" onclick="showPage('explore')">Explorar</a>
                    <a href="../HTML/Equipos.php" class="nav-link" onclick="showPage('teams')">Equipos</a>
                    <a href="../HTML/Calificaciones.php" class="nav-link" onclick="showPage('statistics')">Estadísticas</a>
                </div>
                
                <div class="user-menu">
                    <div style="display:flex;align-items:center;gap:.6rem;">
                        <div style="text-align:right;">
                            <div style="font-size:.85rem;"><?php echo htmlspecialchars($usuario_correo); ?></div>
                            <div style="font-size:.75rem;color:var(--muted);">Bienvenido</div>
                        </div>
                        <div class="user-avatar"><?php echo strtoupper(substr($usuario_correo,0,2)); ?></div>
                    </div>
                </div>
            </nav>
        </div>
    </header>

<main class="container">
  <h2>Proyectos de todos los usuarios</h2>
  <div class="projects-grid">
    <?php foreach($projects as $p): ?>
      <div class="project-card">
        <h3 class="project-title"><?php echo htmlspecialchars($p['nombre']); ?></h3>
        <p class="project-description"><?php echo htmlspecialchars($p['descripcion']); ?></p>
        <div class="project-files">
          <strong>Archivos:</strong>
          <?php
            $files = $archivos_por_proyecto[$p['id']] ?? [];
            if(empty($files)) echo '<div class="file-link">No hay archivos</div>';
            else {
                foreach($files as $f){
                    echo '<a class="file-link" href="'.htmlspecialchars($f['ruta']).'" target="_blank">'.htmlspecialchars($f['nombre_archivo']).'</a>';
                }
            }
          ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</main>
</body>
</html>