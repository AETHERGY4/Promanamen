<?php
// ver_proyecto.php
// Colocar en: C:\xampp\htdocs\Promanagen\HTML\ver_proyecto.php

// DEBUG - mostrar errores (solo en desarrollo)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_error.log');

session_start();
// Para pruebas locales puedes forzar un usuario de desarrollo:
// $_SESSION['usuario_id'] = $_SESSION['usuario_id'] ?? 1;

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ./Inicio.html");
    exit;
}

$usuario_id = (int)$_SESSION['usuario_id'];
$usuario_correo = $_SESSION['usuario_correo'] ?? 'Usuario';

// proyecto_id por GET (requerido)
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "Proyecto no especificado. Usa ?id=ID en la URL.";
    exit;
}
$proyecto_id = (int)$_GET['id'];

// Rutas: la carpeta uploads está UNA carpeta arriba de HTML
$uploadsBaseDir = realpath(__DIR__ . "/../uploads");
if ($uploadsBaseDir === false) {
    // crear uploads si no existe
    $try = __DIR__ . "/../uploads";
    if (!is_dir($try)) @mkdir($try, 0755, true);
    $uploadsBaseDir = realpath($try);
}
$publicPrefix = '/Promanagen/uploads'; // URL pública base

// Conexión BD
$conn = new mysqli("localhost", "root", "", "promanage");
if ($conn->connect_error) {
    die("Conexión BD: " . $conn->connect_error);
}

// Helper PRG
function redirect_with_msg($url, $msg = '') {
    if ($msg !== '') {
        $sep = (strpos($url, '?') === false) ? '?' : '&';
        $url .= $sep . 'msg=' . urlencode($msg);
    }
    header("Location: " . $url);
    exit;
}

$msg = '';

// POST handling
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Crear actividad
    if (isset($_POST['action']) && $_POST['action'] === 'add_activity') {
        $nombre = trim($_POST['nombre'] ?? '');
        $miembro = trim($_POST['miembro'] ?? '');
        $fecha_inicio = $_POST['fecha_inicio'] ?? null;
        $fecha_fin = $_POST['fecha_fin'] ?? null;
        $estado = trim($_POST['estado'] ?? 'pendiente');

        if ($nombre === '' || $miembro === '' || !$fecha_inicio) {
            $msg = "Completa nombre, miembro y fecha inicio para crear la actividad.";
        } else {
            $stmt = $conn->prepare("INSERT INTO actividades (proyecto_id, nombre, miembro, fecha_inicio, fecha_fin, estado) VALUES (?, ?, ?, ?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param("isssss", $proyecto_id, $nombre, $miembro, $fecha_inicio, $fecha_fin, $estado);
                if ($stmt->execute()) {
                    // crear carpeta física para la actividad (opcional)
                    $insert_id = $stmt->insert_id;
                    $dir = $uploadsBaseDir . DIRECTORY_SEPARATOR . $usuario_id . DIRECTORY_SEPARATOR . $proyecto_id . DIRECTORY_SEPARATOR . "actividad_{$insert_id}";
                    if (!is_dir($dir)) @mkdir($dir, 0755, true);
                    redirect_with_msg("/Promanagen/HTML/ver_proyecto.php?id=" . intval($proyecto_id), "Actividad creada correctamente.");
                } else {
                    $msg = "Error al crear actividad: " . $stmt->error;
                }
                $stmt->close();
            } else {
                $msg = "Error en la consulta de actividades: " . $conn->error;
            }
        }
    }

    // Eliminar archivo
    if (isset($_POST['action']) && $_POST['action'] === 'delete_file' && isset($_POST['archivo_id'])) {
        $archivo_id = (int)$_POST['archivo_id'];
        $stmt = $conn->prepare("SELECT id, ruta FROM archivos WHERE id = ? AND proyecto_id = ? LIMIT 1");
        if ($stmt) {
            $stmt->bind_param("ii", $archivo_id, $proyecto_id);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($row = $res->fetch_assoc()) {
                $ruta = $row['ruta'];

                // Mapear ruta pública a ruta física
                $fullpath = null;
                if (strpos($ruta, $publicPrefix) === 0) {
                    $relative = substr($ruta, strlen($publicPrefix));
                    $fullpath = $uploadsBaseDir . $relative;
                } else {
                    // fallback: buscar por basename en uploads
                    $basename = basename(parse_url($ruta, PHP_URL_PATH));
                    if (is_dir($uploadsBaseDir)) {
                        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($uploadsBaseDir));
                        foreach ($it as $f) {
                            if ($f->isFile() && $f->getFilename() === $basename) {
                                $fullpath = $f->getPathname();
                                break;
                            }
                        }
                    }
                }

                if ($fullpath && is_file($fullpath)) {
                    @unlink($fullpath);
                }

                $del = $conn->prepare("DELETE FROM archivos WHERE id = ? LIMIT 1");
                if ($del) {
                    $del->bind_param("i", $archivo_id);
                    $del->execute();
                    $del->close();
                }

                $conn->query("UPDATE proyectos SET ultimo_commit = NOW() WHERE id = " . intval($proyecto_id));
                redirect_with_msg("/Promanagen/HTML/ver_proyecto.php?id=" . intval($proyecto_id), "Archivo eliminado.");
            } else {
                $msg = "Archivo no encontrado o no pertenece al proyecto.";
            }
            $stmt->close();
        } else {
            $msg = "Error en la consulta al intentar borrar: " . $conn->error;
        }
    }

    // Subir archivo (vinculado a actividad)
    if (isset($_POST['action']) && $_POST['action'] === 'upload_file' && isset($_POST['actividad_id']) && isset($_FILES['archivo'])) {
        $actividad_id = (int)$_POST['actividad_id'];
        $file = $_FILES['archivo'];

        if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
            $msg = "Error al subir archivo (código " . ($file['error'] ?? 'no_file') . ").";
        } else {
            // Carpeta física: ../uploads/{usuario_id}/{proyecto_id}/actividad_{actividad_id}/
            $baseDir = rtrim($uploadsBaseDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $usuario_id . DIRECTORY_SEPARATOR . $proyecto_id . DIRECTORY_SEPARATOR . "actividad_{$actividad_id}" . DIRECTORY_SEPARATOR;
            if (!is_dir($baseDir)) {
                if (!mkdir($baseDir, 0755, true) && !is_dir($baseDir)) {
                    $msg = "No se pudo crear la carpeta de destino.";
                }
            }

            if (empty($msg)) {
                $origName = basename($file['name']);
                $safeBase = preg_replace('/[^A-Za-z0-9_\-\.]/', '_', pathinfo($origName, PATHINFO_FILENAME));
                $ext = pathinfo($origName, PATHINFO_EXTENSION);
                try {
                    $unique = time() . '_' . bin2hex(random_bytes(6)) . '_' . $safeBase . ($ext ? '.' . $ext : '');
                } catch (Exception $e) {
                    $unique = time() . '_' . mt_rand(100000, 999999) . '_' . $safeBase . ($ext ? '.' . $ext : '');
                }
                $target = $baseDir . $unique;

                if (move_uploaded_file($file['tmp_name'], $target)) {
                    $webPath = rtrim($publicPrefix, '/') . "/{$usuario_id}/{$proyecto_id}/actividad_{$actividad_id}/" . rawurlencode($unique);

                    // Insertar registro en DB
                    $ins = $conn->prepare("INSERT INTO archivos (proyecto_id, nombre_archivo, ruta, fecha_subida) VALUES (?, ?, ?, NOW())");
                    if ($ins) {
                        $ins->bind_param("iss", $proyecto_id, $unique, $webPath);
                        if ($ins->execute()) {
                            $ins->close();
                            $conn->query("UPDATE proyectos SET ultimo_commit = NOW() WHERE id = " . intval($proyecto_id));
                            redirect_with_msg("/Promanagen/HTML/ver_proyecto.php?id=" . intval($proyecto_id), "Archivo subido correctamente.");
                        } else {
                            @unlink($target);
                            $msg = "Archivo subido pero error al guardar en BD: " . $ins->error;
                            $ins->close();
                        }
                    } else {
                        @unlink($target);
                        $msg = "Error en la consulta de inserción: " . $conn->error;
                    }
                } else {
                    $msg = "Error al mover el archivo al directorio final.";
                }
            }
        }
    }
}

// --- Obtener datos para mostrar ---
// Info proyecto
$stmtP = $conn->prepare("SELECT nombre, descripcion FROM proyectos WHERE id = ? LIMIT 1");
$stmtP->bind_param("i", $proyecto_id);
$stmtP->execute();
$resP = $stmtP->get_result();
$proyecto = $resP->fetch_assoc() ?: ['nombre' => 'Proyecto desconocido', 'descripcion' => ''];
$stmtP->close();

// Actividades
$stmtA = $conn->prepare("SELECT id, nombre, miembro, fecha_inicio, fecha_fin, estado FROM actividades WHERE proyecto_id = ? ORDER BY fecha_inicio ASC, id ASC");
$stmtA->bind_param("i", $proyecto_id);
$stmtA->execute();
$resA = $stmtA->get_result();
$actividades = [];
while ($r = $resA->fetch_assoc()) $actividades[] = $r;
$stmtA->close();

// Archivos
$archivos_por_actividad = [];
$archivos_sin_actividad = [];
$stmtF = $conn->prepare("SELECT id, nombre_archivo, ruta, fecha_subida FROM archivos WHERE proyecto_id = ? ORDER BY fecha_subida DESC");
$stmtF->bind_param("i", $proyecto_id);
$stmtF->execute();
$resF = $stmtF->get_result();
while ($f = $resF->fetch_assoc()) {
    if (preg_match('#actividad_(\d+)#', $f['ruta'], $m)) {
        $aid = (int)$m[1];
        $archivos_por_actividad[$aid][] = $f;
    } else {
        $archivos_sin_actividad[] = $f;
    }
}
$stmtF->close();

$conn->close();

if (isset($_GET['msg'])) $msg = $_GET['msg'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Proyecto: <?php echo htmlspecialchars($proyecto['nombre']); ?></title>
<style>
:root{--header-bg:#161b22;--text:#c9d1d9;--muted:#8b949e;--btn:#238636;--surface:#161b22;}
body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial;background:#0d1117;color:var(--text);}
.header{display:flex;justify-content:space-between;align-items:center;padding:12px 20px;background:var(--header-bg);gap:12px;}
.container{max-width:1100px;margin:20px auto;padding:1rem;}
.repositorio{background:var(--surface);padding:20px;border-radius:10px;margin-bottom:16px;}
.btn{background:var(--btn);color:#fff;padding:.45rem .7rem;border-radius:8px;border:none;cursor:pointer;}
.btn-outline{background:transparent;border:1px solid rgba(255,255,255,0.06);color:var(--text);padding:.45rem .7rem;border-radius:8px;}
.input{padding:8px;border-radius:6px;background:#0d1117;border:1px solid rgba(255,255,255,0.03);color:var(--text);}
.activity-list{display:flex;flex-direction:column;gap:12px;margin-top:12px;}
.activity{background:#0f1418;padding:12px;border-radius:8px;}
.file-item{display:flex;justify-content:space-between;align-items:center;padding:6px 8px;background:rgba(255,255,255,0.01);border-radius:6px;margin:6px 0;}
.small{font-size:0.85rem;color:var(--muted);}
.note{color:var(--muted);font-size:0.9rem;margin-top:6px;}
.input-file{display:none;}
@media(max-width:700px){.input,.upload-form{width:100%;}}
</style>
</head>
<body>
<header class="header">
  <div style="display:flex;gap:12px;align-items:center;">
    <a href="../HTML/index.php" class="btn btn-outline">← Volver</a>
    <div>
      <div style="font-weight:700;"><?php echo htmlspecialchars($proyecto['nombre']); ?></div>
      <div class="small" style="margin-top:2px;"><?php echo htmlspecialchars($proyecto['descripcion']); ?></div>
    </div>
  </div>
  <div style="display:flex;align-items:center;gap:12px;">
    <div class="small" style="text-align:right;"><?php echo htmlspecialchars($usuario_correo); ?><br><span class="small">Proyecto ID: <?php echo $proyecto_id; ?></span></div>
    <div style="width:40px;height:40px;border-radius:8px;background:rgba(255,255,255,0.04);display:flex;align-items:center;justify-content:center;"><?php echo strtoupper(substr($usuario_correo,0,2)); ?></div>
  </div>
</header>

<main class="container">
  <?php if ($msg): ?>
    <div class="repositorio"><div><?php echo htmlspecialchars($msg); ?></div></div>
  <?php endif; ?>

  <div class="repositorio">
    <h2>Actividades</h2>
    <p class="note">Agrega actividades y sube archivos por actividad.</p>

    <form method="post" class="form-row" style="margin-top:12px;">
      <input type="hidden" name="action" value="add_activity">
      <input class="input" type="text" name="nombre" placeholder="Título de la actividad" style="flex:2" required>
      <input class="input" type="text" name="miembro" placeholder="Miembro" style="flex:1" required>
      <input class="input" type="date" name="fecha_inicio" required>
      <input class="input" type="date" name="fecha_fin">
      <select name="estado" class="input" style="width:160px;">
        <option value="pendiente">Pendiente</option>
        <option value="en progreso">En progreso</option>
        <option value="completada">Completada</option>
      </select>
      <button type="submit" class="btn">Crear Actividad</button>
    </form>

    <div class="activity-list">
      <?php if (count($actividades) === 0): ?>
        <div class="note">Aún no hay actividades.</div>
      <?php else: foreach ($actividades as $act): ?>
        <div class="activity">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <div>
              <div style="font-weight:700;"><?php echo htmlspecialchars($act['nombre']); ?></div>
              <div class="small">Asignado: <?php echo htmlspecialchars($act['miembro']); ?> — <?php echo htmlspecialchars($act['fecha_inicio']); ?> <?php echo $act['fecha_fin'] ? "a {$act['fecha_fin']}" : ''; ?></div>
            </div>
            <div style="display:flex;gap:8px;">
              <!-- ver_actividad.php opcional -->
              <!--<a href="ver_actividad.php?id=<?php echo $act['id']; ?>" class="btn btn-outline" style="background:transparent;color:var(--text)">Ver</a>-->
            </div>
          </div>

          <div class="file-list">
            <div class="small" style="margin-bottom:6px;">Archivos asociados:</div>
            <?php
              $aid = (int)$act['id'];
              $files = $archivos_por_actividad[$aid] ?? [];
              if (empty($files)) echo '<div class="note">No hay archivos.</div>';
              else {
                foreach ($files as $f) {
                  $ruta = htmlspecialchars($f['ruta']);
                  $nombre_archivo = htmlspecialchars($f['nombre_archivo']);
                  $fecha_subida = htmlspecialchars($f['fecha_subida']);
                  $archivo_id = (int)$f['id'];
                  echo "<div class='file-item'>";
                  echo "<div><a href='{$ruta}' target='_blank' style='color:var(--text);text-decoration:none;'>{$nombre_archivo}</a><div class='small'>{$fecha_subida}</div></div>";
                  echo "<div style='display:flex;gap:8px;align-items:center;'>";
                  echo "<div class='small' style='max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;'>{$ruta}</div>";
                  echo "<form method='post' onsubmit=\"return confirm('¿Eliminar este archivo?');\" style='margin:0;'>";
                  echo "<input type='hidden' name='action' value='delete_file'>";
                  echo "<input type='hidden' name='archivo_id' value='{$archivo_id}'>";
                  echo "<button type='submit' class='btn btn-outline' style='background:transparent;color:var(--text);'>Eliminar</button>";
                  echo "</form>";
                  echo "</div></div>";
                }
              }
            ?>
          </div>

          <form method="post" enctype="multipart/form-data" style="margin-top:8px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
            <input type="hidden" name="action" value="upload_file">
            <input type="hidden" name="actividad_id" value="<?php echo $act['id']; ?>">
            <label class="btn btn-outline" style="cursor:pointer;">
              <input class="input-file" type="file" name="archivo" onchange="this.closest('form').querySelector('.file-name').textContent = this.files[0] ? this.files[0].name : 'Ningún archivo seleccionado';">
              Seleccionar archivo
            </label>
            <div class="small file-name" style="min-width:180px;color:var(--muted)">Ningún archivo seleccionado</div>
            <button type="submit" class="btn">Subir</button>
          </form>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>

  <div class="repositorio">
    <h3>Archivos sin actividad</h3>
    <?php if (empty($archivos_sin_actividad)) echo '<div class="note">No hay archivos sin actividad.</div>'; else {
      foreach ($archivos_sin_actividad as $f) {
        $archivo_id = (int)$f['id'];
        $ruta = htmlspecialchars($f['ruta']);
        $nombre_archivo = htmlspecialchars($f['nombre_archivo']);
        $fecha_subida = htmlspecialchars($f['fecha_subida']);
        echo "<div class='file-item'><div><a href='{$ruta}' target='_blank'>{$nombre_archivo}</a><div class='small'>{$fecha_subida}</div></div>";
        echo "<div style='display:flex;gap:8px;align-items:center;'><div class='small' style='max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;'>{$ruta}</div>";
        echo "<form method='post' onsubmit=\"return confirm('¿Eliminar este archivo?');\" style='margin:0;'>";
        echo "<input type='hidden' name='action' value='delete_file'><input type='hidden' name='archivo_id' value='{$archivo_id}'>";
        echo "<button type='submit' class='btn btn-outline' style='background:transparent;color:var(--text);'>Eliminar</button></form></div></div>";
      }
    } ?>
  </div>
</main>

<script>
document.querySelectorAll('.input-file').forEach(inp=>{
  inp.addEventListener('change',function(){
    const form=this.closest('form');
    const nameEl=form.querySelector('.file-name');
    if(this.files && this.files.length) nameEl.textContent=this.files[0].name;
    else nameEl.textContent='Ningún archivo seleccionado';
  });
});
// evitar doble submit (opcional)
document.querySelectorAll('form').forEach(form=>{
  form.addEventListener('submit',function(){
    const btn = this.querySelector('button[type="submit"]');
    if(btn){ btn.disabled=true; btn.dataset.old=btn.textContent; btn.textContent='Procesando...'; }
  });
});
</script>
</body>
</html>