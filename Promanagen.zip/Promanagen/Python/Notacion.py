#Primero se definen cuales son operadores y los partentesis
OPERADORES = set(['+', '-', '*', '/', '^'])
PARENTESIS = set(['(', ')'])

#se agrega la prieridad de cada elenebto para agregar a la pila 
def prioridad(op):
    if op == '^': return 4
    if op in ('*', '/'): return 3
    if op in ('+', '-'): return 2
    return 0

def es_asociativo_derecha(op):
    # '^' si tiene un valor mas alto a la derecha; los demás ( + - * / ) son izquierda
    return op == '^'

def es_operador(tok):
    return tok in OPERADORES

def tokenizar(expr):
    """Convierte la cadena en lista de tokens: números (multi-cifra, decimales), identificadores, paréntesis y operadores."""
    tokens = []
    i = 0
    n = len(expr)
    while i < n:
        c = expr[i]
        if c.isspace():
            i += 1
            continue
        # número (multi-cifra, con punto decimal opcional)
        if c.isdigit() or (c == '.' and i+1 < n and expr[i+1].isdigit()):
            num = c
            i += 1
            while i < n and (expr[i].isdigit() or expr[i] == '.'):
                num += expr[i]; i += 1
            tokens.append(num)
            continue
        # identifica: letras, puede incluir dígitos después.
        if c.isalpha():
            idf = c
            i += 1
            while i < n and (expr[i].isalnum() or expr[i] == '_'):
                idf += expr[i]; i += 1
            tokens.append(idf)
            continue
        # paréntesis u operador toma un solo caracter.
        if c in OPERADORES or c in PARENTESIS:
            tokens.append(c)
            i += 1
            continue
        # carácter desconocido el usuario vera un error ya que no esta en la lista
        tokens.append(c)
        i += 1
    return tokens

def infija_a_postfija(expr):
    tokens = tokenizar(expr)
    salida = []
    pila = []

    for tok in tokens:
        # 2. Si es operando (número o identificador), pasarlo a la salida.
        if tok not in OPERADORES and tok not in PARENTESIS:
            salida.append(tok)
            continue

        # 3. Si es operador:
        if es_operador(tok):
            # 3.1 Si la pila está vacía, meterlo.
            if not pila or pila[-1] == '(':
                pila.append(tok)
                continue

            # 3.2 Si la pila no está vacía: comparar prioridades y asociatividad
            while pila and pila[-1] != '(' and es_operador(pila[-1]):
                cima = pila[-1]
                prec_cima = prioridad(cima)
                prec_tok = prioridad(tok)

                # Condición para desapilar según asociatividad y prioridad:
                # Si 'tokens' es izquierda-asociativa y su prioridad <= cima -> desapilar cima.
                # Si 'tokens' es derecha-asociativa y su prioridad < cima -> desapilar cima.
                if (not es_asociativo_derecha(tok) and prec_tok <= prec_cima) or \
                   (es_asociativo_derecha(tok) and prec_tok < prec_cima):
                    salida.append(pila.pop())
                    # volver a comparar con nueva cima (volvemos al while)
                else:
                    break
            # meter el operador leído
            pila.append(tok)
            continue

        # 4. Si es paréntesis derecho/izquierdo
        if tok == '(':
            pila.append(tok)
            continue
        if tok == ')':
            # 4.1 Sacar hasta encontrar '('
            while pila and pila[-1] != '(':
                salida.append(pila.pop())
            # 4.2 Suprimir '(' si existe
            if pila and pila[-1] == '(':
                pila.pop()
            else:
                # paréntesis desbalanceados -> dejamos el flujo detecta en caso de que el usuario lo ponga mal
                raise ValueError("Paréntesis estan mal checa tu operacion: falta '('")
            continue

    # 5. Si quedan elementos en la pila, pasarlos a la salida.
    while pila:
        cima = pila.pop()
        if cima in ('(', ')'):
            raise ValueError("Paréntesis esta mal en la expresión.")
        salida.append(cima)

    return ' '.join(salida)

#aqui interactua el usuario
if __name__ == "__main__":
    try:
        expr = input("Ingresa una expresión por favor: ")
        rpn = infija_a_postfija(expr)
        print("Notación postfija:", rpn)
    except Exception as e:
        print("Error:", e)