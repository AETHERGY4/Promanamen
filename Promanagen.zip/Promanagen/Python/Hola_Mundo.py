# Este es un comentario:
# nuestro hola mundo en Python
print("Hola mundo")
print('Hola mundo')

"""
Este es un
comentario
en varias lineas
"""

'''
Este tambien es un
comentario
en varias lineas
'''

# consultar el tipo de dato
print(type("Soy un dato str")) # Tipo "str"
print(type(5)) # Tipo "int"
print(type(1.5)) # Tipo "float"
print(type(True)) # Tipo "bool"
print(type(1 + 2j)) # Tipo "complex"
