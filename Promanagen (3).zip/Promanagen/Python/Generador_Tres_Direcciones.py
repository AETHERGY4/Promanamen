# Conversor de Expresion Infija a Postfija
# Convierte una expresion infija a notacion postfija y guarda SOLO la notacion postfija en un archivo .txt

OPERADORES = set(['+', '-', '*', '/', '^'])
PARENTESIS = set(['(', ')'])


def prioridad(op):
    if op == '^':
        return 4
    if op in ('*', '/'):
        return 3
    if op in ('+', '-'):
        return 2
    return 0


def es_asociativo_derecha(op):
    return op == '^'


def es_operador(tok):
    return tok in OPERADORES


def tokenizar(expr):
    """Convierte la cadena en lista de tokens: numeros (multi-cifra, decimales), identificadores, parentesis y operadores."""
    tokens = []
    i = 0
    n = len(expr)
    while i < n:
        c = expr[i]
        if c.isspace():
            i += 1
            continue
        # numero (multi-cifra, con punto decimal opcional)
        if c.isdigit() or (c == '.' and i + 1 < n and expr[i + 1].isdigit()):
            num = c
            i += 1
            punto_encontrado = (c == '.')
            while i < n and (expr[i].isdigit() or expr[i] == '.'):
                if expr[i] == '.':
                    if punto_encontrado:
                        raise ValueError(
                            f"Error: numero invalido con multiples puntos decimales en posicion {i}")
                    punto_encontrado = True
                num += expr[i]
                i += 1
            tokens.append(num)
            continue
        # identificador: letra inicial, luego letras/digitos/_
        if c.isalpha():
            idf = c
            i += 1
            while i < n and (expr[i].isalnum() or expr[i] == '_'):
                idf += expr[i]
                i += 1
            tokens.append(idf)
            continue
        # parentesis u operador de un caracter
        if c in OPERADORES or c in PARENTESIS:
            tokens.append(c)
            i += 1
            continue
        raise ValueError(f"Error: caracter no valido '{c}' en posicion {i}")
    return tokens


def infija_a_postfija(expr):
    """Convierte expresion infija a postfija (lista de tokens)."""
    if not expr or not expr.strip():
        raise ValueError("Error: la expresion esta vacia")

    tokens = tokenizar(expr)
    salida = []
    pila = []

    for tok in tokens:
        # operando -> salida
        if tok not in OPERADORES and tok not in PARENTESIS:
            salida.append(tok)
            continue

        # operador
        if es_operador(tok):
            if not pila or pila[-1] == '(':
                pila.append(tok)
                continue
            while pila and pila[-1] != '(' and es_operador(pila[-1]):
                cima = pila[-1]
                prec_cima = prioridad(cima)
                prec_tok = prioridad(tok)
                if (not es_asociativo_derecha(tok) and prec_tok <= prec_cima) or \
                   (es_asociativo_derecha(tok) and prec_tok < prec_cima):
                    salida.append(pila.pop())
                else:
                    break
            pila.append(tok)
            continue

        # parentesis
        if tok == '(':
            pila.append(tok)
            continue
        if tok == ')':
            while pila and pila[-1] != '(':
                salida.append(pila.pop())
            if pila and pila[-1] == '(':
                pila.pop()
            else:
                raise ValueError("Parentesis mal balanceados: falta '('")
            continue

    while pila:
        cima = pila.pop()
        if cima in ('(', ')'):
            raise ValueError("Parentesis mal balanceados en la expresion")
        salida.append(cima)

    return salida


def parsear_expresion_con_igual(entrada):
    """Parsea una entrada que puede tener formato 'variable = expresion' o solo 'expresion'.
    Devuelve (variable, expresion) donde variable puede ser None si no hay '='.
    """
    entrada = entrada.strip()
    if '=' in entrada:
        partes = entrada.split('=', 1)  # Dividir solo en el primer '='
        variable = partes[0].strip()
        expresion = partes[1].strip()
        return variable, expresion
    return None, entrada

def generar_codigo_p_desde_postfija(tokens_postfijos, nombre_variable_final=None):
    """Genera codigo P a partir de una lista de tokens en notacion postfija.
    Si hay variable: lda variable, luego las operaciones, y al final sto.
    Si no hay variable: solo las operaciones.
    """
    codigo_p = []
    
    # Iniciar con lda solo si hay una variable definida
    if nombre_variable_final:
        codigo_p.append(f"lda {nombre_variable_final}")
    
    # Procesar tokens de la postfija
    for token in tokens_postfijos:
        if token.isdigit() or ('.' in token and token.replace('.', '').isdigit()):
            # Es un numero (constante)
            codigo_p.append(f"ldc {token}")
        elif token.isalpha() or (token.replace('_', '').isalnum()):
            # Es una variable
            codigo_p.append(f"lod {token}")
        elif token in OPERADORES:
            # Es un operador
            if token == '+':
                codigo_p.append("adi")
            elif token == '-':
                codigo_p.append("sbi")
            elif token == '*':
                codigo_p.append("mpi")
            elif token == '/':
                codigo_p.append("dvi")  # Nota: segun el ejemplo usa "dvi" para division
            elif token == '^':
                codigo_p.append("mpi")
    
    # Terminar con sto solo si hay una variable definida
    if nombre_variable_final:
        codigo_p.append("sto")
    
    return codigo_p

def generar_tres_direcciones_desde_postfija(tokens_postfijos, nombre_variable_final=None):
    """Genera codigo de tres direcciones a partir de una lista de tokens en notacion postfija.
    Si hay variable: la ultima operacion se asigna directamente a la variable final.
    Si no hay variable: solo genera temporales sin asignacion final.
    """
    pila = []
    instrucciones = []
    contador_temp = 1
    
    # Contar cuantos operadores hay en total
    total_operadores = sum(1 for tok in tokens_postfijos if tok in OPERADORES)
    operadores_procesados = 0

    for tok in tokens_postfijos:
        # operando: variable o numero
        if tok.isdigit() or ('.' in tok and tok.replace('.', '', 1).isdigit()) or tok[0].isalpha():
            pila.append(tok)
            continue
        # operador binario: sacar 2 operandos
        if tok in OPERADORES:
            if len(pila) < 2:
                raise ValueError("Postfija invalida: faltan operandos")
            op2 = pila.pop()  # derecha
            op1 = pila.pop()  # izquierda
            operadores_procesados += 1
            
            # Si es el ultimo operador y hay variable, asignar directamente a la variable final
            if operadores_procesados == total_operadores and nombre_variable_final:
                instrucciones.append(f"{nombre_variable_final} = {op1} {tok} {op2}")
                pila.append(nombre_variable_final)
            else:
                # Crear un temporal (t1, t2, t3, ...)
                t = f"t{contador_temp}"
                contador_temp += 1
                instrucciones.append(f"{t} = {op1} {tok} {op2}")
                pila.append(t)
            continue
        raise ValueError(f"Token no reconocido en postfija: {tok}")

    if len(pila) != 1:
        raise ValueError("Postfija invalida: sobran operandos u operadores")

    return instrucciones

def generar_archivo_postfija(entrada, nombre_archivo="postfija.txt"):
    """Convierte una expresion infija a postfija y genera codigo P y codigo de tres direcciones.
    Genera dos archivos separados: uno para codigo P y otro para codigo de tres direcciones.
    Acepta formato 'variable = expresion' o solo 'expresion'.
    """
    # Parsear si tiene variable antes del '='
    variable, expr_infija = parsear_expresion_con_igual(entrada)
    
    # Convertir a postfija
    postfija = infija_a_postfija(expr_infija)
    
    # Generar codigo P (solo con variable si existe)
    codigo_p = generar_codigo_p_desde_postfija(postfija, variable)
    
    # Generar codigo de tres direcciones
    # Si no hay variable, generar solo temporales sin asignación final
    codigo_tac = generar_tres_direcciones_desde_postfija(postfija, variable)
    
    # Generar strings
    postfija_str = ' '.join(postfija)
    codigo_p_str = '\n'.join(codigo_p)
    codigo_tac_str = '\n'.join(codigo_tac)

    # Generar nombres de archivos
    if nombre_archivo.endswith('.txt'):
        base_nombre = nombre_archivo[:-4]
    else:
        base_nombre = nombre_archivo
    
    archivo_p = f"{base_nombre}_P.txt"
    archivo_tac = f"{base_nombre}_TAC.txt"

    # Guardar codigo P en su archivo
    with open(archivo_p, 'w', encoding='utf-8') as f:
        f.write(codigo_p_str)
    
    # Guardar codigo de tres direcciones en su archivo
    with open(archivo_tac, 'w', encoding='utf-8') as f:
        f.write(codigo_tac_str)

    return archivo_p, archivo_tac, postfija_str, variable


def mostrar_ayuda():
    print("=" * 70)
    print("AYUDA - CONVERSOR A POSTFIJA")
    print("=" * 70)
    print("Operadores soportados: +  -  *  /  ^")
    print("Ejemplos de expresiones:")
    print("  3 + 4 * 2")
    print("  (a + b) * (c - d)")
    print("  x ^ 2 + y * z")
    print("  5.5 + 3.2 * 2.1")
    print()
    print("Tambien puedes usar formato 'variable = expresion':")
    print("  r = (4-3)+8/(4-3)")
    print("  resultado = 3 + 4 * 2")
    print("  x = a + b * c")
    print("-" * 70)


def main():
    print("=" * 70)
    print("CONVERSOR INFIJA A POSTFIJA")
    print("=" * 70)
    print("Convierte una expresion infija a notacion postfija y la guarda en .txt")
    print("Escribe 'ayuda' para ejemplos, 'salir' para terminar.")
    print("-" * 70)

    while True:
        try:
            expr = input("\nIngresa una expresion infija (o 'variable = expresion'): ").strip()
            if expr.lower() in ('salir', 'exit', 'quit', ''):
                print("\n[OK] Hasta luego!")
                break
            if expr.lower() in ('ayuda', 'help', 'h'):
                mostrar_ayuda()
                continue

            nombre_archivo = input("Nombre del archivo de salida (por defecto 'postfija.txt'): ").strip()
            if not nombre_archivo:
                nombre_archivo = 'postfija.txt'
            elif not nombre_archivo.endswith('.txt'):
                nombre_archivo += '.txt'

            archivo_p, archivo_tac, postfija_str, variable = generar_archivo_postfija(expr, nombre_archivo)
            print("\n[OK] Archivos generados exitosamente!")
            if variable:
                print(f"[*] Variable detectada: {variable}")
            print(f"[*] Archivo codigo P: {archivo_p}")
            print(f"[*] Archivo codigo tres direcciones: {archivo_tac}")
            print(f"[*] Notacion postfija: {postfija_str}")
        except Exception as e:
            print(f"[ERROR] {e}")


if __name__ == '__main__':
    main()
