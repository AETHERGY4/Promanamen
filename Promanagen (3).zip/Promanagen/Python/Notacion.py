# -*- coding: utf-8 -*-
OPERADORES = set(['+', '-', '*', '/', '^'])
PARENTESIS = set(['(', ')'])

# Prioridades: ^ > * / > + -
def prioridad(op):
    if op == '^': return 4
    if op in ('*', '/'): return 3
    if op in ('+', '-'): return 2
    return 0

# Asociatividad: '^' es right-associative, los demás left
ASOCIATIVIDAD = {
    '^': 'right',
    '+': 'left',
    '-': 'left',
    '*': 'left',
    '/': 'left'
}

def es_operador(tok):
    return tok in OPERADORES

def es_numero(tok):
    try:
        float(tok)
        return True
    except:
        return False

def tokenizar(expr):
    tokens = []
    i = 0
    n = len(expr)
    while i < n:
        c = expr[i]
        if c.isspace():
            i += 1
            continue
        if c.isdigit() or (c == '.' and i+1 < n and expr[i+1].isdigit()):
            num = c
            i += 1
            while i < n and (expr[i].isdigit() or expr[i]=='.'):
                num += expr[i]; i += 1
            tokens.append(num)
            continue
        if c.isalpha() or c == '_':
            idf = c
            i += 1
            while i < n and (expr[i].isalnum() or expr[i]=='_'):
                idf += expr[i]; i += 1
            tokens.append(idf)
            continue
        # reconocer ^ también como operador
        if c in OPERADORES or c in PARENTESIS or c == '=':
            tokens.append(c)
            i += 1
            continue
        tokens.append(c)
        i += 1
    return tokens

def infija_a_postfija(tokens):
    salida = []
    pila = []
    for tok in tokens:
        if tok == '':
            continue
        if tok not in OPERADORES and tok not in PARENTESIS:
            salida.append(tok)
            continue
        if es_operador(tok):
            # si tok es left-assoc: pop mientras prioridad(tok) <= prioridad(pila[-1])
            # si tok es right-assoc: pop mientras prioridad(tok) < prioridad(pila[-1])
            while (pila and pila[-1] != '(' and es_operador(pila[-1]) and
                   (
                       (ASOCIATIVIDAD.get(tok, 'left') == 'left' and prioridad(tok) <= prioridad(pila[-1]))
                       or
                       (ASOCIATIVIDAD.get(tok, 'left') == 'right' and prioridad(tok) < prioridad(pila[-1]))
                   )):
                salida.append(pila.pop())
            pila.append(tok)
            continue
        if tok == '(':
            pila.append(tok)
            continue
        if tok == ')':
            while pila and pila[-1] != '(':
                salida.append(pila.pop())
            if pila and pila[-1] == '(':
                pila.pop()
            continue
    while pila:
        salida.append(pila.pop())
    return salida

def generar_codigo_p(expr):
    expr = expr.strip()
    codigo_p = []
    postfija = []

    # Verificar si hay asignación
    if '=' in expr:
        var_lhs, rhs = expr.split('=', 1)
        var_lhs = var_lhs.strip()
        tokens_rhs = tokenizar(rhs)
        postfija = infija_a_postfija(tokens_rhs)

        # LDA al inicio solo para x o y (según tu convención)
        if var_lhs in ['x', 'y']:
            codigo_p.append(f"lda {var_lhs}")

        # Generar código p para RHS
        for tok in postfija:
            if not es_operador(tok):
                if es_numero(tok):
                    codigo_p.append(f"ldc {tok}")
                else:
                    codigo_p.append(f"lod {tok}")
            else:
                if tok == '+':
                    codigo_p.append("adi")
                elif tok == '-':
                    codigo_p.append("sbi")
                elif tok == '*':
                    codigo_p.append("mpi")
                elif tok == '/':
                    codigo_p.append("dvi")
                elif tok == '^':
                    codigo_p.append("pwr")   # instrucción ejemplo para potencia

        # Almacenar resultado en LHS
        if var_lhs in ['x','y']:
            codigo_p.append("sto")
    else:
        # No hay asignación, solo expresión suelta
        tokens = tokenizar(expr)
        postfija = infija_a_postfija(tokens)
        for tok in postfija:
            if not es_operador(tok):
                if es_numero(tok):
                    codigo_p.append(f"ldc {tok}")
                else:
                    codigo_p.append(f"lod {tok}")
            else:
                if tok == '+':
                    codigo_p.append("adi")
                elif tok == '-':
                    codigo_p.append("sbi")
                elif tok == '*':
                    codigo_p.append("mpi")
                elif tok == '/':
                    codigo_p.append("dvi")
                elif tok == '^':
                    codigo_p.append("pwr")
        # Imprimir resultado
        codigo_p.append("wri")

    return postfija, codigo_p

def generar_codigo_3dir(postfija, var_lhs=None):
    pila = []
    codigo = []
    temp_idx = 1
    for tok in postfija:
        if not es_operador(tok):
            pila.append(tok)
        else:
            # Asegurarnos de que haya dos operandos (si falta, usar '0' como marcador)
            op2 = pila.pop() if pila else '0'
            op1 = pila.pop() if pila else '0'
            temp_var = f"t{temp_idx}"
            # Para mostrar el operador tal cual (incluye '^')
            codigo.append(f"{temp_var} = {op1} {tok} {op2}")
            pila.append(temp_var)
            temp_idx += 1

    # Si hay asignación final al LHS
    if var_lhs:
        if pila:
            resultado_final = pila.pop()
            # Asignar LHS = resultado_final (sin crear temporal extra)
            codigo.append(f"{var_lhs} = {resultado_final}")
        else:
            # No hubo operaciones (por ejemplo: x = 5), tomar el último token de la postfija si existe
            if postfija:
                codigo.append(f"{var_lhs} = {postfija[-1]}")
    return codigo

def guardar_resultados_txt(codigo_p, codigo_3dir, nombre_codigo_p="codigo_p.txt", nombre_3dir="codigo_3direcciones.txt"):
    # Guardar codigo p
    with open(nombre_codigo_p, "w", encoding="utf-8") as f:
        # Escribir líneas (sin cabezera para mantener tu formato original)
        for linea in codigo_p:
            f.write(linea + "\n")
    # Guardar codigo de 3 direcciones
    with open(nombre_3dir, "w", encoding="utf-8") as f:
        for linea in codigo_3dir:
            f.write(linea + "\n")
    print(f"Se guardó codigo p en: {nombre_codigo_p}")
    print(f"Se guardó codigo de 3 direcciones en: {nombre_3dir}")

# --- Interfaz ---
if __name__ == "__main__":
    expr = input("Ingresa tu ecuación o expresión: ")
    if '=' in expr:
        var_lhs = expr.split('=')[0].strip()
    else:
        var_lhs = None
    postfija, codigo_p = generar_codigo_p(expr)
    codigo_3dir = generar_codigo_3dir(postfija, var_lhs)


    print("")
    for linea in codigo_p:
        print(linea)

    print("")
    for linea in codigo_3dir:
        print(linea)

    guardar_resultados_txt(codigo_p, codigo_3dir)

#　　　　　　　 　 　 　 　 ／: : : : : : : : : : : : : : : : : : : : : : ヽ{////}
#　 　 　 　 　 　 　 　 ／: : : : : : : : : : : : : : : : : : : : : : : : : :.ヾ///|
#　　　　　　　　　　 ,.: : : : : : : : : : : : : :.:i: : : : : : }: : : : : : : : :.:∨/ﾄ､
#　　　　　　　ー=彡７: : : : : : : : : : : : :/|: : : : : :,' ＼:.: : : : : : : :V,|: :＼
#　　　　　　　　{//,'/ : : : : : : : : : : : :/ :|: : : : :厶‐‐ ヽ: : : : : : :.Ⅵ: : : :ヽ
#　　　　　　　　|/,'/: : : : : : : : : :_:_:_/　 |: : : :/　 　 　 ‘，: : : : : :}}: : : : :.:ヽ
#　　　　　　 　 Ⅳ′: : : : : : : ´: ://｀　 |: : :/ 　 ｘｆ斧ﾐｘi : : : : : : ﾄ､: : : : : ‘，
#　　　　　　 　 i: :ｉ: : :./ : : : : : :.y'斧ミx.}:／　　 弋::ソ j}.: :.: : : : :.|　ヽ: : : : :‘，
#　　　 　 　 　 ,:.:.|: :./i: : : : : : 《 弋::ソ ´　　　　　　　　, : : : : : : !| 　 ‘，: : : :‘，
#　　　　　　　/ :ノイ　! : : : : /:.　　　　　　　　　 　 　 /: :./: : : :.八　　 !: : : : : ‘，
#.　　　　　　/: : : :.:| 　ヽ: : ://ﾊ　　　　　　'　　　　　厶イ : : : /　　　　| : : : : : : :
#　　　　　 /.: :.: : :.:|　　 ）ノ∨/,'ヽ　　　　　　　 　　 ／ jハ／ 　 　 　 | : : : : : : :
#. 　　　　/.: : :.: : :.:|　　´　　 ｀く⌒ ＞　 　 ^　 　 イ　　　（　　　　　　 | : : : : : : :
#　　　　/.: : :.: : : :.:|　　 　 　 　 ヽ:/　r:| ｀　‐　´　ﾉ:}　　　　　 　 　 　 | : : : : : : :
#.　　　/.: : : : :.: : :.:|　　　 　 ___　 __,ノ|: ー ､　_／: : ﾄ､　　__ 　　　　　 | : : : : : : :