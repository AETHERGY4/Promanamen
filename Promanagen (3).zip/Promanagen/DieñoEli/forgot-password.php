<?php
// forgot-password.php
session_start();
$conn = new mysqli("localhost","root","","promanage");
if ($conn->connect_error) die("Error BD: " . $conn->connect_error);

$msg = '';
$link_html = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = trim($_POST['correo'] ?? '');
    if ($correo === '') {
        $msg = "Ingresa tu correo.";
    } elseif (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $msg = "Ingresa un correo válido.";
    } else {
        // buscar usuario
        $stmt = $conn->prepare("SELECT id, nombre FROM usuarios WHERE correo = ? LIMIT 1");
        $stmt->bind_param("s", $correo);
        $stmt->execute();
        $res = $stmt->get_result();
        $user = $res->fetch_assoc();
        $stmt->close();

        if (!$user) {
            // por seguridad no decimos si existe o no
            $msg = "Si hay una cuenta con ese correo, la solicitud fue enviada para revisión.";
        } else {
            // buscar la última solicitud
            $stmt = $conn->prepare("SELECT id, estado, token, fecha FROM solicitudes_recuperacion WHERE correo = ? ORDER BY fecha DESC LIMIT 1");
            $stmt->bind_param("s", $correo);
            $stmt->execute();
            $res = $stmt->get_result();
            $sol = $res->fetch_assoc();
            $stmt->close();

            if ($sol) {
                if ($sol['estado'] === 'pendiente') {
                    $msg = "Tu solicitud está pendiente de aprobación del administrador.";
                } elseif ($sol['estado'] === 'aprobado' && !empty($sol['token'])) {
                    // Construir link — si tu cambiar_contrasena.php está en esta carpeta ajusta ruta
                    $token = rawurlencode($sol['token']);
                    // Si usas URL absoluta, cámbiala por la real (o la de config)
                    $base = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https://" : "http://")
                          . $_SERVER['HTTP_HOST']
                          . dirname($_SERVER['REQUEST_URI']);
                    $link = rtrim($base, '/\\') . "/cambiar_contrasena.php?token={$token}";
                    $msg = "Solicitud aprobada. Usa el siguiente enlace para cambiar tu contraseña (válido temporalmente):";
                    // Generamos HTML seguro para mostrar
                    $link_html = "<div style='margin-top:8px;padding:10px;background:#0f1720;border-radius:8px;'><a href='".htmlspecialchars($link)."' style='color:#78f;word-break:break-all;'>".htmlspecialchars($link)."</a></div>";
                } else {
                    $msg = "Solicitud en estado desconocido o sin token. Contacta al administrador.";
                }
            } else {
                // crear nueva solicitud pendiente
                $stmt = $conn->prepare("INSERT INTO solicitudes_recuperacion (correo, estado, fecha) VALUES (?, 'pendiente', NOW())");
                $stmt->bind_param("s", $correo);
                if ($stmt->execute()) {
                    $msg = "Solicitud creada y enviada para revisión del administrador.";
                } else {
                    $msg = "Error al crear solicitud: " . $stmt->error;
                }
                $stmt->close();
            }
        }
    }
}
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Recuperar contraseña</title>
<link rel="stylesheet" href="../CSS/Login.css">
<style>
.container{max-width:420px;margin:40px auto;background:rgba(255,255,255,0.04);padding:20px;border-radius:12px;color:#fff}
.input{width:100%;padding:10px;border-radius:8px;border:none;background:rgba(0,0,0,0.15);color:#fff;margin:8px 0}
.btn{background:#238636;color:#fff;padding:10px 14px;border-radius:8px;border:none;cursor:pointer}
.notice{background:rgba(0,0,0,0.12);padding:10px;border-radius:8px;margin-bottom:10px}
</style>
</head>
<body style="background:linear-gradient(135deg,#4b6cb7,#182848);font-family:system-ui;color:#fff;">
  <div class="container">
    <h2>Recuperar contraseña</h2>
    <p class="small">Ingresa tu correo para solicitar recuperación.</p>

    <?php if($msg): ?>
      <div class="notice"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>

    <?php if($link_html): ?>
      <!-- Si hay enlace lo mostramos también -->
      <?php echo $link_html; ?>
    <?php endif; ?>

    <form method="post" action="">
      <input class="input" type="email" name="correo" placeholder="tu@unlock.edu.mx" required>
      <button class="btn" type="submit">Verificar / Enviar solicitud</button>
    </form>

    <div style="margin-top:12px;">
      <a href="login.html" style="color:#fff;text-decoration:none">← Volver al inicio</a>
    </div>
  </div>
</body>
</html>