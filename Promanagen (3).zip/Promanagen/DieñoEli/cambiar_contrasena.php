<?php
session_start();
$conn = new mysqli("localhost", "root", "", "promanage");
if ($conn->connect_error) die("Error BD: ".$conn->connect_error);

$token = $_GET['token'] ?? '';

if(!$token) die("Token inválido.");

// Verificar token aprobado
$stmt = $conn->prepare("SELECT correo FROM solicitudes_recuperacion WHERE token=? AND estado='aprobado' LIMIT 1");
$stmt->bind_param("s",$token);
$stmt->execute();
$res = $stmt->get_result();
$sol = $res->fetch_assoc();
$stmt->close();

if(!$sol) die("Token inválido o ya usado.");

if($_SERVER['REQUEST_METHOD']==='POST'){
    $contrasena = trim($_POST['contrasena'] ?? '');
    $confirmar = trim($_POST['confirmar'] ?? '');
    if(!$contrasena || !$confirmar){
        $msg = "Llena ambos campos.";
    } elseif($contrasena !== $confirmar){
        $msg = "Las contraseñas no coinciden.";
    } else {
        $correo = $sol['correo'];
        $stmt = $conn->prepare("UPDATE usuarios SET contrasena=? WHERE correo=?");
        $hash = password_hash($contrasena, PASSWORD_DEFAULT);
        $stmt->bind_param("ss", $hash, $correo);
        $stmt->execute();
        $stmt->close();

        // Eliminar token
        $stmt = $conn->prepare("DELETE FROM solicitudes_recuperacion WHERE token=?");
        $stmt->bind_param("s",$token);
        $stmt->execute();
        $stmt->close();

        // Redirigir a Recuperar.html después de cambiar contraseña
        header("Location: ../HTML/Restablecido.html");
        exit; // siempre después de header()
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cambiar Contraseña - ProjectFolio</title>
<link rel="stylesheet" href="../CSS/Login.css">
</head>
<body>
<div class="auth-container">
  <div class="auth-card">
    <div class="auth-header">
      <div class="logo"><span>📁</span>TESPROY</div>
      <h1 class="auth-title">Cambiar Contraseña</h1>
      <p class="auth-subtitle">Ingresa tu nueva contraseña</p>
    </div>
    <?php if(!empty($msg)): ?>
      <div class="success-message"><?php echo $msg; ?></div>
    <?php endif; ?>
    <form method="POST">
      <div class="form-group">
        <label class="form-label">Nueva Contraseña</label>
        <input type="password" name="contrasena" class="form-input" required>
      </div>
      <div class="form-group">
        <label class="form-label">Confirmar Contraseña</label>
        <input type="password" name="confirmar" class="form-input" required>
      </div>
      <button type="submit" class="btn btn-primary">Cambiar Contraseña</button>
    </form>
  </div>
</div>
</body>
</html>