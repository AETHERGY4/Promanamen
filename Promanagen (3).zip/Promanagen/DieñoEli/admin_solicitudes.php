<?php
// admin_solicitudes.php
session_start();
$conn = new mysqli("localhost","root","","promanage");
if ($conn->connect_error) die("Error BD: " . $conn->connect_error);

// valida sesión admin (ajusta según tu auth)
if (!isset($_SESSION['admin']) || !$_SESSION['admin']) {
    die("Acceso denegado.");
}

$msg = '';
$extra_info = '';

// --- valores por defecto si no hay config ---
$base_url = "http://localhost/Promanagen"; // ajusta a tu ruta
$from_email = "no-reply@unlock.edu.mx";

// aprobar (POST para evitar CSRF simple)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aprobar_id'])) {
    $id = (int)$_POST['aprobar_id'];
    // obtener solicitud
    $stmt = $conn->prepare("SELECT id, correo FROM solicitudes_recuperacion WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $sol = $res->fetch_assoc();
    $stmt->close();

    if (!$sol) {
        $msg = "Solicitud no encontrada.";
    } else {
        $token = bin2hex(random_bytes(16));
        $stmt = $conn->prepare("UPDATE solicitudes_recuperacion SET estado='aprobado', token = ?, fecha = NOW() WHERE id = ?");
        $stmt->bind_param("si", $token, $id);
        if ($stmt->execute()) {
            $msg = "Solicitud aprobada y token generado.";
            // construir enlace
            $link = rtrim($base_url, '/') . "/cambiar_contrasena.php?token=" . rawurlencode($token);
            // enviar correo
            $to = $sol['correo'];
            $subject = "Solicitud aprobada - Cambia tu contraseña";
            $body = "Hola,\n\nTu solicitud para recuperar contraseña ha sido aprobada.\n\nAccede al siguiente enlace para cambiar tu contraseña:\n\n{$link}\n\nSi no solicitaste esto, ignora este correo.\n\nSaludos,\nProjectFolio";
            $headers = "From: " . $from_email . "\r\n";
            $sent = @mail($to, $subject, $body, $headers);
            if ($sent) {
                $extra_info = "Correo enviado al usuario ({$to}).";
            } else {
                $extra_info = "No se pudo enviar correo (mail()). Copia el enlace manualmente si es necesario.";
            }
            $extra_info .= "<div style='margin-top:8px;padding:8px;background:#f5f5f5;border-radius:6px;'><strong>Link para usuario:</strong><br><a href='".htmlspecialchars($link)."' target='_blank'>".htmlspecialchars($link)."</a></div>";
        } else {
            $msg = "Error al actualizar la solicitud: " . $conn->error;
        }
        $stmt->close();
    }
}

// obtener todas las solicitudes
$res = $conn->query("SELECT * FROM solicitudes_recuperacion ORDER BY fecha DESC");
$solicitudes = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
$conn->close();
?>
<!doctype html>
<html lang="es">
<head><meta charset="utf-8"><meta name="viewport"content="width=device-width,initial-scale=1">
<title>Admin - Solicitudes</title>
<link rel="stylesheet" href="../CSS/Login.css">
<style>
.container{max-width:900px;margin:20px auto}
.card{background:#fff;padding:18px;border-radius:10px}
table{width:100%;border-collapse:collapse}
th,td{padding:10px;border-bottom:1px solid #eee;text-align:left}
.btn{background:#238636;color:#fff;padding:8px 10px;border-radius:8px;border:none;cursor:pointer}
.notice{background:#eef8ee;color:#154215;padding:10px;border-radius:8px;margin-bottom:12px}
</style>
</head>
<body style="font-family:system-ui;">
<div class="container">
  <div class="card">
    <h2>Solicitudes de Recuperación</h2>
    <?php if($msg): ?><div class="notice"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if($extra_info): echo "<div style='margin-bottom:12px;'>{$extra_info}</div>"; endif; ?>

    <?php if(empty($solicitudes)): ?>
      <p>No hay solicitudes.</p>
    <?php else: ?>
      <table>
        <thead><tr><th>ID</th><th>Correo</th><th>Estado</th><th>Token</th><th>Fecha</th><th>Acción</th></tr></thead>
        <tbody>
          <?php foreach($solicitudes as $s): ?>
            <tr>
              <td><?php echo (int)$s['id']; ?></td>
              <td><?php echo htmlspecialchars($s['correo']); ?></td>
              <td><?php echo htmlspecialchars($s['estado']); ?></td>
              <td><?php echo htmlspecialchars($s['token'] ?? ''); ?></td>
              <td><?php echo htmlspecialchars($s['fecha']); ?></td>
              <td>
                <?php if($s['estado'] === 'pendiente'): ?>
                  <form method="post" style="display:inline">
                    <input type="hidden" name="aprobar_id" value="<?php echo (int)$s['id']; ?>">
                    <button class="btn" type="submit" onclick="return confirm('Aprobar solicitud?')">Aprobar</button>
                  </form>
                <?php else: ?>
                  Aprobada
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
    <div style="margin-top:12px;"><a href="admin_login.php">← Volver</a></div>
  </div>
</div>
</body>
</html>