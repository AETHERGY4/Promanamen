<?php
session_start();
$error = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $correo = trim($_POST['correo'] ?? '');
    $pass = trim($_POST['contrasena'] ?? '');

    // Cambia por credenciales reales de tu admin
    $admin_email = 'admin@tuescuela.edu.mx';
    $admin_pass = '123';

    if($correo === $admin_email && $pass === $admin_pass){
        $_SESSION['admin'] = true;
        $_SESSION['admin_correo'] = $correo;
        header("Location: admin_solicitudes.php");
        exit;
    } else {
        $error = "Credenciales incorrectas";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login Admin</title>
<link rel="stylesheet" href="../CSS/Login.css">
</head>
<body>
<div class="auth-container">
  <div class="auth-card">
    <h1 class="auth-title">Login Administrador</h1>
    <?php if($error): ?><div class="error-message"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <form method="post" autocomplete="off">
      <div class="form-group">
        <label class="form-label">Correo</label>
        <input type="email" name="correo" class="form-input" required>
      </div>
      <div class="form-group">
        <label class="form-label">Contraseña</label>
        <input type="password" name="contrasena" class="form-input" required>
      </div>
      <button class="btn btn-primary" type="submit">Entrar</button>
    </form>
  </div>
</div>
</body>
</html>