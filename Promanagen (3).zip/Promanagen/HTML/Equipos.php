<?php
session_start();
if (!isset($_SESSION['usuario_id'])) header("Location: ../HTML/Inicio.html");

$usuario_id = (int)$_SESSION['usuario_id'];
$usuario_correo = $_SESSION['usuario_correo'] ?? 'Usuario';

// Conexión a BD
$conn = new mysqli("localhost","root","","promanage");
if ($conn->connect_error) die("Conexión fallida: ".$conn->connect_error);

// Obtener proyectos donde eres owner o integrante
$query = "
    SELECT DISTINCT p.id, p.nombre, p.descripcion, p.fecha_creacion, p.ultimo_commit, p.usuario_id AS owner_id
    FROM proyectos p
    LEFT JOIN integrantes i ON i.proyecto_id = p.id
    WHERE p.usuario_id = ? OR i.usuario_id = ?
    ORDER BY p.fecha_creacion DESC
";
$stmt = $conn->prepare($query);
if (!$stmt) die("Error en prepare: " . $conn->error);
$stmt->bind_param("ii", $usuario_id, $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$teams = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Equipos - TESPROY</title>
<link rel="stylesheet" href="/Promanagen/CSS/Equipos.css">
<style>
body{margin:0;font-family:system-ui;background:#0d1117;color:#c9d1d9;}
.container{max-width:1100px;margin:0 auto;padding:1rem;}
.main-header{background:#161b22;padding:.8rem 0;border-bottom:1px solid rgba(255,255,255,0.03);}
.navbar{display:flex;justify-content:space-between;align-items:center;gap:1rem;}
.logo{color:#c9d1d9;text-decoration:none;font-weight:700;}
.nav-links{display:flex;gap:.6rem;align-items:center;}
.nav-link{color:#8b949e;text-decoration:none;padding:.4rem .6rem;border-radius:6px;}
.nav-link.active{color:#c9d1d9;background:rgba(255,255,255,0.02);}
.user-menu{display:flex;gap:.6rem;align-items:center;}
.user-avatar{width:36px;height:36px;background:rgba(255,255,255,0.06);display:flex;align-items:center;justify-content:center;border-radius:6px;color:#c9d1d9;font-weight:700;}
.teams-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:1rem;margin-top:1rem;}
.team-card{background:#161b22;padding:1rem;border-radius:10px;border:1px solid rgba(255,255,255,0.02);}
.team-avatar{width:44px;height:44px;background:rgba(255,255,255,0.06);display:flex;align-items:center;justify-content:center;border-radius:6px;color:#c9d1d9;font-weight:700;margin-bottom:.5rem;}
.meta{color:#8b949e;font-size:.9rem;margin-top:.5rem;}
</style>
</head>
<body>
<header class="main-header">
    <div class="container">
        <nav class="navbar">
            <!-- Botón Volver -->
            <a href="../HTML/index.php" class="btn">← Volver</a>

            <!-- Logo -->
            <a class="logo">📁 TESPROY</a>

            <!-- Links de navegación -->
            <div class="nav-links">
                <a href="../HTML/index.php" class="nav-link active">Mi Espacio</a>
                <a href="../HTML/Explorar.php" class="nav-link">Explorar</a>
                <a href="../HTML/Equipos.php" class="nav-link">Equipos</a>
                <a href="../HTML/Calificaciones.php" class="nav-link">Estadísticas</a>
            </div>

            <!-- Usuario -->
            <div class="user-menu">
                <div style="display:flex;align-items:center;gap:.6rem;">
                    <div style="text-align:right;">
                        <div style="font-size:.85rem;"><?php echo htmlspecialchars($usuario_correo); ?></div>
                        <div style="font-size:.75rem;color:#8b949e;">Bienvenido</div>
                    </div>
                    <div class="user-avatar"><?php echo strtoupper(substr($usuario_correo,0,2)); ?></div>
                </div>
            </div>
        </nav>
    </div>
</header>

<main class="container">
    <h2>Mis Equipos / Proyectos</h2>

    <div class="teams-grid">
        <?php if (empty($teams)): ?>
            <div class="team-card">
                <p>No estás asignado a ningún proyecto todavía.</p>
            </div>
        <?php else: ?>
            <?php foreach($teams as $t): ?>
                <div class="team-card">
                    <div class="team-avatar"><?php echo strtoupper(substr($t['nombre'],0,2)); ?></div>
                    <h3><?php echo htmlspecialchars($t['nombre']); ?></h3>
                    <p><?php echo htmlspecialchars($t['descripcion']); ?></p>
                    <div class="meta">
                        <small>Creado: <?php echo htmlspecialchars($t['fecha_creacion']); ?></small>
                        <br>
                        <small><?php echo ((int)$t['owner_id'] === $usuario_id) ? 'Propietario' : 'Integrante'; ?></small>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</main>
</body>
</html>