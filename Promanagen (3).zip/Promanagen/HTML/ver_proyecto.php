<?php
// ver_proyecto.php - Banco de proyectos con secciones: video / docs / code
// Versión: añade detección automática de lenguajes en la sección "Código fuente"

// DEBUG (solo desarrollo)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_error.log');

session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ./Inicio.html");
    exit;
}

$usuario_id = (int)$_SESSION['usuario_id'];
$usuario_correo = $_SESSION['usuario_correo'] ?? 'Usuario';

// proyecto_id por GET
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "Proyecto no especificado. Usa ?id=ID en la URL.";
    exit;
}
$proyecto_id = (int)$_GET['id'];

// paths
$uploadsBaseDir = realpath(__DIR__ . "/../uploads");
if ($uploadsBaseDir === false) {
    $try = __DIR__ . "/../uploads";
    if (!is_dir($try)) @mkdir($try, 0755, true);
    $uploadsBaseDir = realpath($try);
}
$publicPrefix = '/Promanagen/uploads';

// DB
$conn = new mysqli("localhost", "root", "", "promanage");
if ($conn->connect_error) die("Conexión BD: " . $conn->connect_error);

// helpers
function redirect_with_msg($url, $msg = '') {
    if ($msg !== '') {
        $sep = (strpos($url, '?') === false) ? '?' : '&';
        $url .= $sep . 'msg=' . urlencode($msg);
    }
    header("Location: " . $url);
    exit;
}
function sanitize_filename($name) {
    $ext = pathinfo($name, PATHINFO_EXTENSION);
    $base = pathinfo($name, PATHINFO_FILENAME);
    $base = preg_replace('/[^A-Za-z0-9_\-\.]/', '_', $base);
    $ext = preg_replace('/[^A-Za-z0-9]/', '', $ext);
    return $base . ($ext ? '.' . $ext : '');
}
function file_ext($name){ return strtolower(pathinfo($name, PATHINFO_EXTENSION)); }
function is_video_ext($ext){ return in_array($ext, ['mp4','webm','ogg','ogv']); }
function is_text_ext($ext){ return in_array($ext, ['php','js','py','java','c','cpp','h','html','css','txt','json','xml','md','sql','rb','go','rs','swift','kt']); }

// allowed extensions per section
$allowed = [
    'video' => ['mp4','webm','ogg','ogv'],
    'docs'  => ['pdf','doc','docx','ppt','pptx','odt','txt','md','zip','rar'],
    'code'  => ['zip','tar','gz','php','js','py','java','c','cpp','html','css','txt','json','rb','go','rs','swift','kt'],
];

// POST handling: subir por sección / eliminar archivo
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // eliminar archivo
    if (isset($_POST['action']) && $_POST['action'] === 'delete_file' && isset($_POST['archivo_id'])) {
        $archivo_id = (int)$_POST['archivo_id'];
        $stmt = $conn->prepare("SELECT ruta FROM archivos WHERE id=? AND proyecto_id=? LIMIT 1");
        $stmt->bind_param("ii", $archivo_id, $proyecto_id);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($row = $res->fetch_assoc()) {
            $ruta = $row['ruta'];
            $fullpath = null;
            if (strpos($ruta, $publicPrefix) === 0) {
                $relative = substr($ruta, strlen($publicPrefix));
                $fullpath = $uploadsBaseDir . $relative;
            } else {
                $basename = basename(parse_url($ruta, PHP_URL_PATH));
                if (is_dir($uploadsBaseDir)) {
                    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($uploadsBaseDir));
                    foreach ($it as $f) {
                        if ($f->isFile() && $f->getFilename() === $basename) {
                            $fullpath = $f->getPathname();
                            break;
                        }
                    }
                }
            }
            if ($fullpath && is_file($fullpath)) @unlink($fullpath);
            $del = $conn->prepare("DELETE FROM archivos WHERE id=? LIMIT 1");
            $del->bind_param("i", $archivo_id);
            $del->execute();
            $del->close();
            $conn->query("UPDATE proyectos SET ultimo_commit = NOW() WHERE id=" . intval($proyecto_id));
            redirect_with_msg($_SERVER['PHP_SELF'] . "?id={$proyecto_id}", "Archivo eliminado.");
        } else {
            $msg = "Archivo no encontrado o no pertenece al proyecto.";
        }
        $stmt->close();
    }

    // subir archivo por sección
    if (isset($_POST['action']) && strpos($_POST['action'], 'upload_section_') === 0 && isset($_FILES['file'])) {
        $section = str_replace('upload_section_', '', $_POST['action']); // video, docs, code
        if (!in_array($section, ['video','docs','code'])) {
            $msg = "Sección inválida.";
        } else {
            $file = $_FILES['file'];
            if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
                $msg = "Error al subir archivo (código " . ($file['error'] ?? 'no_file') . ").";
            } else {
                $baseDir = rtrim($uploadsBaseDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $usuario_id . DIRECTORY_SEPARATOR . $proyecto_id . DIRECTORY_SEPARATOR . "project" . DIRECTORY_SEPARATOR . $section . DIRECTORY_SEPARATOR;
                if (!is_dir($baseDir) && !mkdir($baseDir, 0755, true) && !is_dir($baseDir)) {
                    $msg = "No se pudo crear carpeta de destino.";
                } else {
                    $origName = basename($file['name']);
                    $safe = sanitize_filename($origName);
                    $ext = file_ext($safe);
                    // validar extensión
                    if (!in_array($ext, $allowed[$section])) {
                        $msg = "Extensión no permitida para la sección {$section}. Extensiones permitidas: " . implode(', ', $allowed[$section]);
                    } else {
                        try { $unique = time() . '_' . bin2hex(random_bytes(6)) . '_' . $safe; }
                        catch (Exception $e) { $unique = time() . '_' . mt_rand(100000,999999) . '_' . $safe; }
                        $target = $baseDir . $unique;
                        if (move_uploaded_file($file['tmp_name'], $target)) {
                            $webPath = rtrim($publicPrefix, '/') . "/{$usuario_id}/{$proyecto_id}/project/{$section}/" . rawurlencode($unique);
                            $ins = $conn->prepare("INSERT INTO archivos (proyecto_id, nombre_archivo, ruta, fecha_subida) VALUES (?, ?, ?, NOW())");
                            $ins->bind_param("iss", $proyecto_id, $unique, $webPath);
                            if ($ins->execute()) {
                                $ins->close();
                                $conn->query("UPDATE proyectos SET ultimo_commit = NOW() WHERE id=" . intval($proyecto_id));
                                redirect_with_msg($_SERVER['PHP_SELF'] . "?id={$proyecto_id}", "Archivo subido a sección {$section}.");
                            } else {
                                @unlink($target);
                                $msg = "Error al guardar en BD: " . $ins->error;
                                $ins->close();
                            }
                        } else {
                            $msg = "Error al mover archivo al directorio final.";
                        }
                    }
                }
            }
        }
    }
}

// obtener info del proyecto + maestro + integrantes + archivos por sección

// info proyecto
$stmt = $conn->prepare("SELECT p.nombre, p.descripcion, p.maestro_id, m.nombre AS maestro_nombre, m.correo AS maestro_correo
                       FROM proyectos p
                       LEFT JOIN maestros m ON m.id = p.maestro_id
                       WHERE p.id = ? LIMIT 1");
$stmt->bind_param("i", $proyecto_id);
$stmt->execute();
$res = $stmt->get_result();
$proyecto = $res->fetch_assoc() ?: ['nombre'=>'Proyecto desconocido','descripcion'=>'','maestro_id'=>null,'maestro_nombre'=>null,'maestro_correo'=>null];
$stmt->close();

// integrantes
$integrantes = [];
$stmt = $conn->prepare("SELECT u.id, u.nombre, u.correo FROM integrantes i JOIN usuarios u ON u.id = i.usuario_id WHERE i.proyecto_id = ?");
$stmt->bind_param("i", $proyecto_id);
$stmt->execute();
$res = $stmt->get_result();
while ($r = $res->fetch_assoc()) $integrantes[] = $r;
$stmt->close();

// archivos (project sections)
$sections_files = ['video'=>[], 'docs'=>[], 'code'=>[]];
$stmt = $conn->prepare("SELECT id, nombre_archivo, ruta, fecha_subida FROM archivos WHERE proyecto_id = ? ORDER BY fecha_subida DESC");
$stmt->bind_param("i", $proyecto_id);
$stmt->execute();
$res = $stmt->get_result();
while ($r = $res->fetch_assoc()) {
    if (strpos($r['ruta'], '/project/video/') !== false) $sections_files['video'][] = $r;
    elseif (strpos($r['ruta'], '/project/docs/') !== false) $sections_files['docs'][] = $r;
    elseif (strpos($r['ruta'], '/project/code/') !== false) $sections_files['code'][] = $r;
    // ignore others
}
$stmt->close();

// ----------------------------
// Detección de lenguajes a partir de extensiones en section 'code'
// Soporta inspección dentro de archivos comprimidos (zip, tar.gz, tgz, rar si están disponibles)
// ----------------------------
$ext_to_lang = [
    'php'=>'PHP','js'=>'JavaScript','py'=>'Python','java'=>'Java','c'=>'C','cpp'=>'C++','cc'=>'C++','cxx'=>'C++','h'=>'C/C++',
    'html'=>'HTML','htm'=>'HTML','css'=>'CSS','json'=>'JSON','xml'=>'XML','rb'=>'Ruby','go'=>'Go','rs'=>'Rust','swift'=>'Swift',
    'kt'=>'Kotlin','kts'=>'Kotlin','sh'=>'Shell','bash'=>'Shell','txt'=>'Texto','sql'=>'SQL','md'=>'Markdown'
];

$languages_used = []; // 'PHP'=>count

// Helper: reconstruir ruta física a partir de ruta web (ruta guardada en BD)
function get_fullpath_from_webpath($ruta, $uploadsBaseDir, $publicPrefix) {
    $fullpath = null;
    if (strpos($ruta, $publicPrefix) === 0) {
        $relative = substr($ruta, strlen($publicPrefix));
        $fullpath = $uploadsBaseDir . $relative;
    } else {
        // fallback: buscar por nombre de archivo dentro de uploads
        $basename = basename(parse_url($ruta, PHP_URL_PATH));
        if (is_dir($uploadsBaseDir)) {
            $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($uploadsBaseDir));
            foreach ($it as $f) {
                if ($f->isFile() && $f->getFilename() === $basename) {
                    $fullpath = $f->getPathname();
                    break;
                }
            }
        }
    }
    return $fullpath;
}

// Helper: a partir de un nombre (o path) obtiene la extensión lowercase
function my_file_ext($name){ return strtolower(pathinfo($name, PATHINFO_EXTENSION)); }

// Helper: procesa un archivo comprimido y devuelve un array de extensiones encontradas dentro (ext => count)
function inspect_archive_for_extensions($fullpath, $container_ext) {
    $found = [];
    if (!is_file($fullpath) || !is_readable($fullpath)) return $found;

    $ext = strtolower($container_ext);

    // ZIP (ZipArchive)
    if ($ext === 'zip' && class_exists('ZipArchive')) {
        $za = new ZipArchive();
        if ($za->open($fullpath) === true) {
            for ($i=0; $i<$za->numFiles; $i++) {
                $stat = $za->statIndex($i);
                if (!$stat) continue;
                $name = $stat['name'];
                if (substr($name, -1) === '/') continue; // dir
                $e = my_file_ext($name);
                if ($e === '') continue;
                if (!isset($found[$e])) $found[$e] = 0;
                $found[$e]++;
            }
            $za->close();
            return $found;
        }
        // si falló ZipArchive, devolvemos vacío para fallback
        return $found;
    }

    // TAR / TGZ / TAR.GZ (PharData)
    if (in_array($ext, ['tar','gz','tgz']) && class_exists('PharData')) {
        try {
            // Si es gz o tgz, PharData puede leer .tar.gz si le pasas la ruta
            $pd = new PharData($fullpath);
            foreach (new RecursiveIteratorIterator($pd) as $file) {
                if ($file->isDir()) continue;
                $name = $file->getFilename();
                $e = my_file_ext($name);
                if ($e === '') continue;
                if (!isset($found[$e])) $found[$e] = 0;
                $found[$e]++;
            }
            return $found;
        } catch (Exception $e) {
            // no se pudo leer con PharData
            return $found;
        }
    }

    // RAR (ext rar instalada)
    if ($ext === 'rar' && function_exists('rar_open')) {
        try {
            $rar = rar_open($fullpath);
            $entries = rar_list($rar);
            foreach ($entries as $ent) {
                $name = $ent->getName();
                if (substr($name, -1) === '/') continue;
                $e = my_file_ext($name);
                if ($e === '') continue;
                if (!isset($found[$e])) $found[$e] = 0;
                $found[$e]++;
            }
            rar_close($rar);
            return $found;
        } catch (Exception $e) {
            return $found;
        }
    }

    // Otros contenedores no soportados: devolver vacío
    return $found;
}

// Recorremos los archivos en la sección 'code' y contabilizamos lenguajes.
// Para archivos comprimidos intentamos inspeccionar su interior.
foreach ($sections_files['code'] as $f) {
    $nombre = $f['nombre_archivo'];
    $ruta = $f['ruta'];
    $ext = my_file_ext($nombre);
    $lang = null;

    // Si es archivo de código/texto normal
    if (isset($ext_to_lang[$ext])) {
        $lang = $ext_to_lang[$ext];
        if (!isset($languages_used[$lang])) $languages_used[$lang] = 0;
        $languages_used[$lang]++;
        continue;
    }

    // Si es un contenedor comprimido intentamos analizar su interior
    if (in_array($ext, ['zip','tar','gz','tgz','rar'])) {
        $fullpath = get_fullpath_from_webpath($ruta, $uploadsBaseDir, $publicPrefix);
        $inspected = [];
        if ($fullpath) {
            $inspected = inspect_archive_for_extensions($fullpath, $ext);
        }

        if (!empty($inspected)) {
            // convertir extensiones encontradas a lenguajes usando $ext_to_lang
            foreach ($inspected as $found_ext => $cnt) {
                $mapped = $ext_to_lang[$found_ext] ?? null;
                if (!$mapped) {
                    // si no hay mapeo, usa mayúsculas de la extensión como etiqueta (ej: ZIP -> "PY" fallback)
                    $mapped = strtoupper($found_ext);
                }
                if (!isset($languages_used[$mapped])) $languages_used[$mapped] = 0;
                $languages_used[$mapped] += $cnt;
            }
            // además, añadir una etiqueta para el contenedor en caso de que no se haya mapeado nada relevante
            if (empty($inspected)) {
                $containerLabel = strtoupper($ext);
                if (!isset($languages_used[$containerLabel])) $languages_used[$containerLabel] = 0;
                $languages_used[$containerLabel]++;
            }
            continue;
        } else {
            // No se pudo inspeccionar (permiso/falta extensión), entonces contar el contenedor genérico
            $containerLabel = strtoupper($ext);
            if (!isset($languages_used[$containerLabel])) $languages_used[$containerLabel] = 0;
            $languages_used[$containerLabel]++;
            continue;
        }
    }

    // Fallback: si no está mapeado, mostrar la extensión en mayúsculas como etiqueta
    $fallback = strtoupper($ext ?: 'FILE');
    if (!isset($languages_used[$fallback])) $languages_used[$fallback] = 0;
    $languages_used[$fallback]++;
}

// ordenar por cantidad desc
arsort($languages_used);

$conn->close();

if (isset($_GET['msg'])) $msg = $_GET['msg'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Banco de Proyecto — <?php echo htmlspecialchars($proyecto['nombre']); ?></title>
<style>
:root{--bg:#0d1117;--surface:#161b22;--text:#c9d1d9;--muted:#8b949e;--accent:#238636;}
body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial;background:var(--bg);color:var(--text);}
.header{display:flex;justify-content:space-between;align-items:center;padding:12px 20px;background:var(--surface);gap:12px;}
.container{max-width:1100px;margin:18px auto;padding:1rem;}
.card{background:var(--surface);padding:18px;border-radius:10px;margin-bottom:14px;border:1px solid rgba(255,255,255,0.02);}
h2{margin:0 0 8px 0;}
.small{font-size:0.9rem;color:var(--muted);}
.btn{background:var(--accent);color:#fff;padding:.45rem .7rem;border-radius:8px;border:none;cursor:pointer;}
.btn-outline{background:transparent;border:1px solid rgba(255,255,255,0.06);color:var(--text);padding:.45rem .7rem;border-radius:8px;}
.input-file{display:none;}
.preview-video{max-width:100%;height:auto;border-radius:8px;background:#000;margin-top:8px;}
.preview-code{background:#0b1114;padding:12px;border-radius:8px;overflow:auto;max-height:360px;border:1px solid rgba(255,255,255,0.03);font-family:Consolas,monospace;font-size:13px;color:var(--text);margin-top:8px;}
.file-row{display:flex;justify-content:space-between;align-items:center;padding:10px;border-radius:8px;background:rgba(255,255,255,0.01);margin:8px 0;}
.meta{color:var(--muted);font-size:0.9rem;}
.section-title{display:flex;justify-content:space-between;align-items:center;gap:12px;}
.chips{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;}
.chip{background:rgba(255,255,255,0.03);padding:6px 10px;border-radius:999px;font-size:0.95rem;}
.lang-chip{background:rgba(35,134,54,0.12);color:#bfe9c9;padding:6px 10px;border-radius:999px;font-size:0.95rem;}
@media(max-width:800px){ .file-row{flex-direction:column;align-items:flex-start;gap:8px;} }
</style>
</head>
<body>
<header class="header">
  <div style="display:flex;gap:12px;align-items:center;">
    <a href="../HTML/index.php" class="btn-outline">← Volver</a>
    <div>
      <div style="font-weight:700;"><?php echo htmlspecialchars($proyecto['nombre']); ?></div>
      <div class="small"><?php echo htmlspecialchars($proyecto['descripcion']); ?></div>
    </div>
  </div>
  <div style="text-align:right;">
    <div class="small"><?php echo htmlspecialchars($usuario_correo); ?></div>
    <div style="width:40px;height:40px;border-radius:8px;background:rgba(255,255,255,0.04);display:inline-flex;align-items:center;justify-content:center;"><?php echo strtoupper(substr($usuario_correo,0,2)); ?></div>
  </div>
</header>

<main class="container">
  <?php if ($msg): ?><div class="card"><div><?php echo htmlspecialchars($msg); ?></div></div><?php endif; ?>

  <!-- Maestro / Integrantes -->
  <div class="card">
    <h2>Seguimiento y equipo</h2>
    <div style="display:flex;gap:16px;align-items:center;flex-wrap:wrap;">
      <div>
        <div style="font-weight:700;">Maestro que da seguimiento</div>
        <?php if ($proyecto['maestro_id']): ?>
          <div class="meta"><?php echo htmlspecialchars($proyecto['maestro_nombre'] ?? '—'); ?> — <span class="small"><?php echo htmlspecialchars($proyecto['maestro_correo'] ?? ''); ?></span></div>
        <?php else: ?>
          <div class="small meta">No hay maestro asignado.</div>
        <?php endif; ?>
      </div>

      <div style="flex:1;">
        <div style="font-weight:700;">Integrantes</div>
        <?php if (empty($integrantes)): ?>
          <div class="small">No hay integrantes agregados.</div>
        <?php else: ?>
          <div class="chips">
            <?php foreach ($integrantes as $u): ?>
              <div class="chip"><?php echo htmlspecialchars($u['nombre']); ?> — <span class="small"><?php echo htmlspecialchars($u['correo']); ?></span></div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Sección: Video -->
  <div class="card">
    <div class="section-title">
      <h2>Video de introducción</h2>
      <div class="small">Formatos permitidos: <?php echo implode(', ', $allowed['video']); ?></div>
    </div>

    <!-- upload form -->
    <form method="post" enctype="multipart/form-data" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:12px;">
      <input type="hidden" name="action" value="upload_section_video">
      <label class="btn btn-outline" style="cursor:pointer;">
        <input class="input-file" type="file" name="file" onchange="this.closest('form').querySelector('.file-name').textContent = this.files[0] ? this.files[0].name : 'Ningún archivo seleccionado'">
        Seleccionar video
      </label>
      <div class="meta file-name" style="min-width:220px;color:var(--muted)">Ningún archivo seleccionado</div>
      <button class="btn" type="submit">Subir video</button>
    </form>

    <?php if (empty($sections_files['video'])): ?>
      <div class="small" style="margin-top:10px;">No hay video en la sección.</div>
    <?php else:
        $first = $sections_files['video'][0];
        $ruta = $first['ruta'];
        $ext = file_ext($first['nombre_archivo']);
    ?>
      <div style="margin-top:12px;">
        <div style="font-weight:700;margin-bottom:6px;">Video destacado</div>
        <video class="preview-video" controls preload="metadata">
          <source src="<?php echo htmlspecialchars($ruta); ?>" type="video/<?php echo htmlspecialchars($ext === 'mp4' ? 'mp4' : $ext); ?>">
          Tu navegador no soporta video.
        </video>
      </div>

      <div style="margin-top:12px;">
        <div style="font-weight:700;">Otros videos (si los hay)</div>
        <?php foreach ($sections_files['video'] as $f):
            $ruta = $f['ruta'];
            $id = (int)$f['id'];
            $nombre = $f['nombre_archivo'];
        ?>
          <div class="file-row">
            <div>
              <div style="font-weight:700;"><?php echo htmlspecialchars($nombre); ?></div>
              <div class="small"><?php echo htmlspecialchars($f['fecha_subida']); ?></div>
            </div>
            <div style="display:flex;gap:8px;align-items:center;">
              <a href="<?php echo htmlspecialchars($ruta); ?>" target="_blank" class="btn-outline" style="background:transparent;color:var(--text);">Abrir</a>
              <form method="post" style="margin:0;">
                <input type="hidden" name="action" value="delete_file">
                <input type="hidden" name="archivo_id" value="<?php echo $id; ?>">
                <button type="submit" class="btn-outline" onclick="return confirm('¿Eliminar este video?')">Eliminar</button>
              </form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

  <!-- Sección: Documentación -->
  <div class="card">
    <div class="section-title">
      <h2>Documentación</h2>
      <div class="small">Formatos permitidos: <?php echo implode(', ', $allowed['docs']); ?></div>
    </div>

    <form method="post" enctype="multipart/form-data" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:12px;">
      <input type="hidden" name="action" value="upload_section_docs">
      <label class="btn btn-outline" style="cursor:pointer;">
        <input class="input-file" type="file" name="file" onchange="this.closest('form').querySelector('.file-name-docs').textContent = this.files[0] ? this.files[0].name : 'Ningún archivo seleccionado'">
        Seleccionar documento
      </label>
      <div class="meta file-name-docs" style="min-width:220px;color:var(--muted)">Ningún archivo seleccionado</div>
      <button class="btn" type="submit">Subir documento</button>
    </form>

    <?php if (empty($sections_files['docs'])): ?>
      <div class="small" style="margin-top:10px;">No hay documentación subida.</div>
    <?php else: ?>
      <?php foreach ($sections_files['docs'] as $f):
        $ruta = $f['ruta']; $id = (int)$f['id']; $nombre = $f['nombre_archivo'];
      ?>
        <div class="file-row">
          <div>
            <div style="font-weight:700;"><?php echo htmlspecialchars($nombre); ?></div>
            <div class="small"><?php echo htmlspecialchars($f['fecha_subida']); ?></div>
          </div>
          <div style="display:flex;gap:8px;align-items:center;">
            <a href="<?php echo htmlspecialchars($ruta); ?>" target="_blank" class="btn-outline" style="background:transparent;color:var(--text);">Abrir / Descargar</a>
            <form method="post" style="margin:0;">
              <input type="hidden" name="action" value="delete_file">
              <input type="hidden" name="archivo_id" value="<?php echo $id; ?>">
              <button type="submit" class="btn-outline" onclick="return confirm('¿Eliminar este documento?')">Eliminar</button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- Sección: Código fuente -->
  <div class="card">
    <div class="section-title">
      <h2>Código fuente</h2>
      <div class="small">Formatos permitidos: <?php echo implode(', ', $allowed['code']); ?></div>
    </div>

    <!-- Lenguajes detectados -->
    <div style="margin-top:8px;">
      <div style="font-weight:700;">Lenguajes detectados</div>
      <?php if (empty($languages_used)): ?>
        <div class="small" style="margin-top:6px;">No se detectaron lenguajes (aún no hay archivos en la sección de código).</div>
      <?php else: ?>
        <div class="chips" style="margin-top:8px;">
          <?php foreach ($languages_used as $lang => $count): ?>
            <div class="lang-chip"><?php echo htmlspecialchars($lang); ?> <span style="opacity:.8;font-size:.85rem;margin-left:6px;">(<?php echo $count; ?>)</span></div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <form method="post" enctype="multipart/form-data" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:12px;">
      <input type="hidden" name="action" value="upload_section_code">
      <label class="btn btn-outline" style="cursor:pointer;">
        <input class="input-file" type="file" name="file" onchange="this.closest('form').querySelector('.file-name-code').textContent = this.files[0] ? this.files[0].name : 'Ningún archivo seleccionado'">
        Seleccionar archivo de código / zip
      </label>
      <div class="meta file-name-code" style="min-width:220px;color:var(--muted)">Ningún archivo seleccionado</div>
      <button class="btn" type="submit">Subir código</button>
    </form>

    <?php if (empty($sections_files['code'])): ?>
      <div class="small" style="margin-top:10px;">No hay código subido.</div>
    <?php else: ?>
      <?php foreach ($sections_files['code'] as $f):
        $ruta = $f['ruta']; $id = (int)$f['id']; $nombre = $f['nombre_archivo']; $ext = file_ext($nombre);
        // calcular ruta física para posibles previews
        $fullpath = null;
        if (strpos($ruta, $publicPrefix) === 0) {
            $relative = substr($ruta, strlen($publicPrefix));
            $fullpath = $uploadsBaseDir . $relative;
        }
      ?>
        <div style="margin-top:8px;">
          <div class="file-row">
            <div>
              <div style="font-weight:700;"><?php echo htmlspecialchars($nombre); ?></div>
              <div class="small"><?php echo htmlspecialchars($f['fecha_subida']); ?></div>
            </div>
            <div style="display:flex;gap:8px;align-items:center;">
              <a href="<?php echo htmlspecialchars($ruta); ?>" target="_blank" class="btn-outline" style="background:transparent;color:var(--text);">Abrir / Descargar</a>
              <?php if (is_text_ext($ext) && is_file($fullpath)): ?>
                <button class="btn-outline" type="button" onclick="toggleCode(<?php echo $id; ?>)">Ver</button>
              <?php endif; ?>
              <form method="post" style="margin:0;">
                <input type="hidden" name="action" value="delete_file">
                <input type="hidden" name="archivo_id" value="<?php echo $id; ?>">
                <button type="submit" class="btn-outline" onclick="return confirm('¿Eliminar este archivo de código?')">Eliminar</button>
              </form>
            </div>
          </div>

          <?php if (is_text_ext($ext) && is_file($fullpath)):
              $content = @file_get_contents($fullpath, false, null, 0, 200*1024);
              $content_esc = htmlspecialchars($content === false ? "[No se pudo leer]" : $content);
          ?>
            <div id="code-<?php echo $id; ?>" class="preview-code" style="display:none;"><?php echo $content_esc; ?></div>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

</main>

<script>
// UI small helpers
document.querySelectorAll('.input-file').forEach(inp=>{
  inp.addEventListener('change',function(){
    const form=this.closest('form');
    const nameEl=form.querySelector('.file-name, .file-name-docs, .file-name-code');
    if(this.files && this.files.length) nameEl.textContent=this.files[0].name;
    else nameEl.textContent='Ningún archivo seleccionado';
  });
});

function toggleCode(id){
  const el = document.getElementById('code-' + id);
  if(!el) return;
  el.style.display = (el.style.display === 'none' || el.style.display === '') ? 'block' : 'none';
  if(el.style.display === 'block') el.scrollIntoView({behavior:'smooth', block:'center'});
}
</script>
</body>
</html>