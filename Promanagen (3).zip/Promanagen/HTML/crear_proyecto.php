<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: Inicio.html");
    exit;
}

// --- Endpoint AJAX: buscar usuarios por correo o nombre ---
if (isset($_GET['ajax_search']) && $_GET['ajax_search'] == '1') {
    header('Content-Type: application/json; charset=utf-8');
    $q = trim($_GET['q'] ?? '');
    $out = [];
    if ($q !== '') {
        $conn = new mysqli("localhost", "root", "", "promanage");
        if (!$conn->connect_errno) {
            $like = '%' . $q . '%';
            // Devolvemos columnas útiles (evitamos devolver contrasena)
            // Columnas: id, correo, nombre, telefono, ubicacion, bio, theme, custom_color, bg_url, btn_color, header_color, text_color
            // Excluimos al usuario creador para evitar añadirte desde la búsqueda
            $currentId = (int)$_SESSION['usuario_id'];
            $stmt = $conn->prepare("
                SELECT id, correo, nombre, telefono, ubicacion, bio, theme, custom_color, bg_url, btn_color, header_color, text_color
                FROM usuarios
                WHERE (correo LIKE ? OR nombre LIKE ?)
                AND id <> ?
                LIMIT 20
            ");
            if ($stmt) {
                $stmt->bind_param("ssi", $like, $like, $currentId);
                $stmt->execute();
                $res = $stmt->get_result();
                while ($r = $res->fetch_assoc()) {
                    $out[] = $r;
                }
                $stmt->close();
            }
            $conn->close();
        }
    }
    echo json_encode($out);
    exit;
}

// --- Resto del flujo normal para crear proyecto ---
$usuario_correo = $_SESSION['usuario_correo'] ?? 'Usuario';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $usuario_id = (int)$_SESSION['usuario_id']; // creador
    $maestro_id = isset($_POST['maestro_id']) ? (int)$_POST['maestro_id'] : null;
    $integrantes = isset($_POST['integrantes']) && is_array($_POST['integrantes']) ? $_POST['integrantes'] : [];

    $conn = new mysqli("localhost", "root", "", "promanage");
    if ($conn->connect_errno) {
        die("Error de conexión: " . $conn->connect_error);
    }

    // Usar transacción para atomicidad
    $conn->autocommit(false);
    try {
        // 1) Insertar proyecto
        $stmt = $conn->prepare("INSERT INTO proyectos (usuario_id, maestro_id, nombre, descripcion) VALUES (?, ?, ?, ?)");
        if (!$stmt) throw new Exception("Prepare proyectos: " . $conn->error);
        $stmt->bind_param("iiss", $usuario_id, $maestro_id, $nombre, $descripcion);
        if (!$stmt->execute()) throw new Exception("Execute proyectos: " . $stmt->error);
        $project_id = $conn->insert_id;
        $stmt->close();

        // 2) Insertar integrantes (incluye el creador siempre)
        $stmtIns = $conn->prepare("INSERT INTO integrantes (proyecto_id, usuario_id) VALUES (?, ?)");
        if (!$stmtIns) throw new Exception("Prepare integrantes: " . $conn->error);

        // Insertar creador como integrante
        $stmtIns->bind_param("ii", $project_id, $usuario_id);
        if (!$stmtIns->execute()) throw new Exception("Execute integrante creador: " . $stmtIns->error);

        // Insertar otros integrantes seleccionados (evitar duplicados)
        $inserted = [$usuario_id => true]; // para no reinsertar al creador
        foreach ($integrantes as $i_uid) {
            $i_uid = (int)$i_uid;
            if ($i_uid <= 0) continue;
            if (isset($inserted[$i_uid])) continue;
            $stmtIns->bind_param("ii", $project_id, $i_uid);
            if (!$stmtIns->execute()) throw new Exception("Execute integrante ($i_uid): " . $stmtIns->error);
            $inserted[$i_uid] = true;
        }
        $stmtIns->close();

        // Commit
        $conn->commit();
        $conn->autocommit(true);
        $conn->close();

        header("Location: index.php");
        exit;
    } catch (Exception $e) {
        $conn->rollback();
        $conn->autocommit(true);
        $conn->close();
        die("Error al crear proyecto: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Crear Proyecto</title>
<link rel="stylesheet" href="/Promanagen/CSS/repositorio.css">
<style>
:root{
  --header-bg: #161b22;
  --text: #c9d1d9;
  --muted: #8b949e;
  --btn: #238636;
}
body { margin:0; font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial; background:#0d1117; color:var(--text); }

.header {
  display:flex;
  justify-content:space-between;
  align-items:center;
  padding:12px 20px;
  background: var(--header-bg);
  color: var(--text);
  box-shadow: 0 2px 6px rgba(0,0,0,0.35);
  gap:12px;
  flex-wrap:wrap;
}
.user-menu { display:flex; gap:.8rem; align-items:center; }
.user-avatar {
  width:44px; height:44px; border-radius:8px;
  background: rgba(255,255,255,0.06);
  display:flex; align-items:center; justify-content:center;
  color: var(--text); font-weight:700;
  font-size:0.95rem;
  flex-shrink:0;
}
.user-info { text-align:right; line-height:1; }
.user-info .name { font-size:0.95rem; font-weight:700; color: var(--text); }
.user-info .sub { font-size:0.78rem; color: var(--muted); }

.nav-links { display:flex; gap:.6rem; align-items:center; margin-left:12px; }
.nav-link {
  color: var(--muted);
  text-decoration:none; padding:.35rem .6rem; border-radius:6px;
  font-size:0.92rem;
}
.nav-link.active { color: var(--text); background: rgba(255,255,255,0.02); }

.header-right { display:flex; align-items:center; gap:.5rem; margin-left:auto; }
.btn {
  background: var(--btn);
  color: #fff;
  padding: .45rem .7rem;
  border-radius:8px;
  text-decoration:none;
  font-weight:600;
  border: none;
  cursor: pointer;
}
.btn:hover { filter:brightness(.95); }

.container{ max-width:1100px; margin:20px auto; padding:1rem; }
.repositorio { background:#161b22; padding:20px; border-radius:10px; color:var(--text); }
.input-field{ width:100%; padding:8px; border-radius:6px; background:#0d1117; border:1px solid rgba(255,255,255,0.03); color:var(--text); }
.label { color:var(--muted); display:block; margin-bottom:6px; }
.small { color:var(--muted); font-size:0.9rem; margin-bottom:8px; }

/* búsqueda */
.search-row { display:flex; gap:8px; align-items:center; margin-top:6px; }
.search-row input { flex:1; }
.results { background:#0b0f12; border:1px solid rgba(255,255,255,0.03); margin-top:6px; border-radius:6px; max-height:220px; overflow:auto; display:none; }
.result-item { padding:8px 10px; cursor:pointer; border-bottom:1px solid rgba(255,255,255,0.02); display:flex; justify-content:space-between; gap:12px; align-items:center; }
.result-left { display:flex; gap:10px; align-items:center; }
.result-meta { color:var(--muted); font-size:0.9rem; }
.result-item:hover { background:rgba(255,255,255,0.02); }

/* chips integrantes */
.chips { display:flex; gap:8px; flex-wrap:wrap; margin-top:10px; }
.chip { background:rgba(255,255,255,0.03); padding:6px 8px; border-radius:999px; display:inline-flex; gap:8px; align-items:center; font-size:0.95rem; }
.chip button { background:transparent; border:none; color:var(--muted); cursor:pointer; padding:0 6px; }

/* responsive */
@media (max-width:800px){ .nav-links{ display:none; } }
</style>
</head>
<body>
<header class="header">
    <div style="display:flex; gap:12px; align-items:center;">
        <div class="user-menu">
            <div style="display:flex;align-items:center;gap:.6rem;">
                <div class="user-info" style="text-align:left;">
                    <div class="name"><?php echo htmlspecialchars($usuario_correo); ?></div>
                    <div class="sub">Crear proyecto</div>
                </div>
                <div class="user-avatar"><?php echo strtoupper(substr($usuario_correo,0,2)); ?></div>
            </div>
        </div>

        <nav class="nav-links" aria-label="Navegación principal">
            <a href="../HTML/index.php" class="nav-link active">Mi Espacio</a>
            <a href="../HTML/Explorar.php" class="nav-link">Explorar</a>
            <a href="../HTML/Equipos.php" class="nav-link">Equipos</a>
            <a href="../HTML/Calificaciones.php" class="nav-link">Estadísticas</a>
        </nav>
    </div>

    <div class="header-right">
        <a href="/Promanagen/HTML/index.php" class="btn">Volver</a>
    </div>
</header>

<main class="container">
    <div class="repositorio">
        <h2>Nuevo Proyecto</h2>
        <form method="post" id="projectForm">
            <label class="label">Nombre:</label>
            <input type="text" name="nombre" required class="input-field"><br>

            <label class="label">Descripción:</label>
            <textarea name="descripcion" class="input-field" style="min-height:100px;"></textarea><br>

            <label class="label">Maestro que administra:</label>
            <select name="maestro_id" required class="input-field">
                <option value="">Selecciona un maestro</option>
                <?php
                // Cargar maestros para el select
                $conn = new mysqli("localhost", "root", "", "promanage");
                if ($conn->connect_errno === 0) {
                    $res = $conn->query("SELECT id, nombre FROM maestros");
                    while($row = $res->fetch_assoc()){
                        echo "<option value='".(int)$row['id']."'>".htmlspecialchars($row['nombre'])."</option>";
                    }
                    $res->free();
                }
                $conn->close();
                ?>
            </select><br>

            <label class="label">Agregar integrantes por correo (o nombre):</label>
            <div class="small">Busca por correo o nombre parcial. Haz clic en un resultado para añadirlo.</div>

            <div class="search-row">
                <input id="searchInput" type="text" placeholder="Ingresa correo o nombre..." class="input-field" autocomplete="off">
                <button type="button" id="searchBtn" class="btn">Buscar</button>
            </div>

            <div id="results" class="results"></div>

            <div class="label" style="margin-top:12px;">Integrantes seleccionados:</div>
            <div id="chips" class="chips"></div>

            <!-- aquí se irán insertando inputs hidden con name="integrantes[]" -->
            <div id="hiddenInputs"></div>

            <div style="margin-top:14px;">
                <button type="submit" class="btn">Crear Proyecto</button>
                <a href="/Promanagen/HTML/index.php" style="margin-left:8px;color:var(--muted);text-decoration:none;">Cancelar</a>
            </div>
        </form>
    </div>
</main>

<script>
// JS para búsqueda por correo/nombre y selección
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');
const resultsEl = document.getElementById('results');
const chipsEl = document.getElementById('chips');
const hiddenInputs = document.getElementById('hiddenInputs');
const selected = {}; // id -> user object

async function doSearch(q) {
    if (!q || q.trim().length < 1) {
        resultsEl.style.display = 'none';
        resultsEl.innerHTML = '';
        return;
    }
    try {
        const resp = await fetch(window.location.pathname + '?ajax_search=1&q=' + encodeURIComponent(q));
        const data = await resp.json();
        renderResults(data);
    } catch (e) {
        console.error(e);
        resultsEl.style.display = 'none';
    }
}

function renderResults(list) {
    resultsEl.innerHTML = '';
    if (!list || list.length === 0) {
        resultsEl.style.display = 'none';
        return;
    }
    list.forEach(u => {
        const div = document.createElement('div');
        div.className = 'result-item';
        div.dataset.uid = u.id;
        const left = document.createElement('div');
        left.className = 'result-left';
        const nameWrap = document.createElement('div');
        nameWrap.innerHTML = `<div><strong>${escapeHtml(u.correo)}</strong></div><div class="result-meta">${escapeHtml(u.nombre || '')}</div>`;
        left.appendChild(nameWrap);

        const right = document.createElement('div');
        right.className = 'result-meta';
        right.textContent = u.telefono ? u.telefono : '';

        div.appendChild(left);
        div.appendChild(right);

        div.addEventListener('click', () => addUser(u));
        resultsEl.appendChild(div);
    });
    resultsEl.style.display = 'block';
}

function addUser(u) {
    if (!u || !u.id) return;
    if (selected[u.id]) return; // ya añadido
    selected[u.id] = u;

    // crear chip
    const chip = document.createElement('div');
    chip.className = 'chip';
    chip.id = 'chip-' + u.id;
    chip.innerHTML = `<span>${escapeHtml(u.nombre || u.correo)} — ${escapeHtml(u.correo)}</span>`;
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.innerText = '✕';
    btn.title = 'Quitar';
    btn.addEventListener('click', () => removeUser(u.id));
    chip.appendChild(btn);
    chipsEl.appendChild(chip);

    // hidden input
    const input = document.createElement('input');
    input.type = 'hidden';
    input.name = 'integrantes[]';
    input.value = u.id;
    input.id = 'hid-' + u.id;
    hiddenInputs.appendChild(input);

    // limpiar búsqueda
    resultsEl.style.display = 'none';
    resultsEl.innerHTML = '';
    searchInput.value = '';
}

function removeUser(uid) {
    delete selected[uid];
    const chip = document.getElementById('chip-' + uid);
    if (chip) chip.remove();
    const hid = document.getElementById('hid-' + uid);
    if (hid) hid.remove();
}

function escapeHtml(s) {
    if (!s) return '';
    return s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#039;');
}

searchBtn.addEventListener('click', () => doSearch(searchInput.value.trim()));
searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        e.preventDefault();
        doSearch(searchInput.value.trim());
    }
});
let debounce;
searchInput.addEventListener('input', () => {
    clearTimeout(debounce);
    debounce = setTimeout(() => {
        const q = searchInput.value.trim();
        if (q.length >= 2) doSearch(q);
        else { resultsEl.style.display = 'none'; resultsEl.innerHTML = ''; }
    }, 250);
});
document.addEventListener('click', (e) => {
    if (!resultsEl.contains(e.target) && e.target !== searchInput && e.target !== searchBtn) {
        resultsEl.style.display = 'none';
    }
});
</script>
</body>
</html>