/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;


import java.util.Scanner;
import javax.swing.JOptionPane;
import java.io.BufferedInputStream;


public class AreaTriangulo {

    // Método que imprime los elementos de un arreglo de enteros
    public static void imprimirArreglo(int[] arreglo) {
        System.out.println("Contenido del arreglo:");
        for (int i = 0; i < arreglo.length; i++) {
            System.out.println("Índice " + i + ": " + arreglo[i]);
        }
    }

    // Método que contiene toda la lógica del programa
    public static void ejecutarPrograma() {
        Scanner scanner = new Scanner(System.in);

        // Declaración de variables separadas
        double base;
        double altura;
        double area; // variable para el resultado

        System.out.print("Ingresa la base del triángulo: ");
        base = scanner.nextDouble();

        System.out.print("Ingresa la altura del triángulo: ");
        altura = scanner.nextDouble();

        // Arreglo de enteros (tipo explícito con [])
        int[] edades = new int[10];
        edades[0] = 5;
        edades[1] = 10;
        edades[2] = 12;
        edades[3] = 15;

        imprimirArreglo(edades);

        // Cálculo del área directamente
        area = (base * altura) / 2;
        System.out.println("El área del triángulo es: " + area);

        // Otros arreglos con tipo explícito
        double[] alturasArray = {1.65, 1.70, 1.80};
        String[] nombres = {"Ana", "Luis", "Carlos", "Maria"};
        double[] calificaciones = {1.65, 1.56, 1.56, 7.22, 3.45, 5.55, 6.88};

        // Solo declaramos los tipos explícitamente para que tu analizador los detecte
        // Scanner sigue siendo un objeto pero ahora se reconoce como clase Scanner
        Scanner lector = new Scanner(System.in);

        scanner.close();
        lector.close();
    }

    // Main para ejecutar el programa
    public static void main(String[] args) {
        ejecutarPrograma();
    }
}




